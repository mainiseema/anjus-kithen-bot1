import { ChatMessage, CustomerChat, Order, WhatsAppTemplate } from '../types';
import { botEngine } from './botEngine';

export interface SendMessageParams {
  message: string;
  chat: CustomerChat;
  history: ChatMessage[];
}

export async function sendChatMessage(params: SendMessageParams): Promise<{
  replyMessage: ChatMessage;
  updatedOrder?: Order;
  escalated?: boolean;
}> {
  try {
    // Try hitting server-side API first
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: params.message,
        customerId: params.chat.id,
        customerPhone: params.chat.phone,
        conversationHistory: params.history.slice(-5).map((m) => ({
          sender: m.sender,
          content: m.content,
        })),
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        // If the server answered with an AI reply
        const botMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          chatId: params.chat.id,
          sender: data.shouldEscalate ? 'agent' : 'bot',
          type: data.matchedOrder ? 'order_card' : 'text',
          content: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'delivered',
          orderId: data.matchedOrder?.id,
          orderData: data.matchedOrder,
          buttons: data.matchedOrder
            ? [
                { id: 'btn-tr-1', title: '📍 Live GPS Status', payload: `track ${data.matchedOrder.id}`, variant: 'primary' },
                { id: 'btn-tr-2', title: '🏠 Update Address', payload: `change address for ${data.matchedOrder.id}`, variant: 'secondary' },
                { id: 'btn-tr-3', title: '👨‍💼 Support Agent', payload: 'agent', variant: 'secondary' },
              ]
            : [
                { id: 'btn-q1', title: '📦 Track My Order', payload: 'track_order', variant: 'primary' },
                { id: 'btn-q2', title: '🛍️ Browse Products', payload: 'browse_catalog', variant: 'secondary' },
                { id: 'btn-q3', title: '🏷️ Discount Codes', payload: 'discount_codes', variant: 'success' },
              ],
          sentiment: data.sentiment || 'neutral',
          agentEscalated: data.shouldEscalate,
        };

        return {
          replyMessage: botMsg,
          updatedOrder: data.matchedOrder,
          escalated: data.shouldEscalate,
        };
      }
    }
  } catch (err) {
    // API endpoint unavailable or offline, seamlessly fallback to local bot engine
    console.debug('Switching to local bot engine fallback');
  }

  // Fallback to rich Bot Engine
  const result = await botEngine.processMessage(params.message, params.chat, params.history);
  return {
    replyMessage: result.message,
    updatedOrder: result.updatedOrder,
    escalated: result.escalated,
  };
}
