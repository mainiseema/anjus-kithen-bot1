import {
  ChatMessage,
  CustomerChat,
  Order,
  Product,
  InteractiveButton,
  InteractiveListSection,
} from '../types';
import {
  INITIAL_ORDERS,
  INITIAL_FAQS,
  DISCOUNT_CODES,
  INITIAL_PRODUCTS,
  DEFAULT_BOT_SETTINGS,
} from '../data/mockData';

export interface BotResponseResult {
  message: ChatMessage;
  additionalMessages?: ChatMessage[];
  updatedOrder?: Order;
  escalated?: boolean;
}

export class WhatsAppBotEngine {
  private orders: Order[] = [...INITIAL_ORDERS];
  private products: Product[] = [...INITIAL_PRODUCTS];
  private settings = { ...DEFAULT_BOT_SETTINGS };

  // Current active orders getter & setter
  public getOrders(): Order[] {
    return this.orders;
  }

  public setOrders(newOrders: Order[]) {
    this.orders = newOrders;
  }

  public updateOrderStatus(orderId: string, status: Order['status'], note?: string): Order | null {
    const idx = this.orders.findIndex((o) => o.id.toUpperCase() === orderId.toUpperCase());
    if (idx === -1) return null;

    const order = this.orders[idx];
    const updated: Order = {
      ...order,
      status,
      notes: note || order.notes,
      deliveredAt: status === 'delivered' ? new Date().toISOString() : order.deliveredAt,
    };

    // Update checkpoints
    const updatedCheckpoints = order.checkpoints.map((chk) => {
      if (status === 'delivered') return { ...chk, completed: true, current: chk.status === 'Delivered' };
      if (status === 'out_for_delivery') {
        if (chk.status === 'Out for Delivery') return { ...chk, completed: true, current: true };
        if (chk.status === 'Delivered') return { ...chk, completed: false, current: false };
        return { ...chk, completed: true, current: false };
      }
      if (status === 'cancelled') return { ...chk, completed: false, current: false };
      return chk;
    });

    updated.checkpoints = updatedCheckpoints;
    this.orders[idx] = updated;
    return updated;
  }

  public updateOrderAddress(orderId: string, street: string, city: string, state: string, postalCode: string): Order | null {
    const idx = this.orders.findIndex((o) => o.id.toUpperCase() === orderId.toUpperCase());
    if (idx === -1) return null;

    this.orders[idx] = {
      ...this.orders[idx],
      shippingAddress: {
        ...this.orders[idx].shippingAddress,
        street,
        city,
        state,
        postalCode,
      },
      notes: `Shipping address updated on ${new Date().toLocaleTimeString()} by customer.`,
    };
    return this.orders[idx];
  }

  public cancelOrder(orderId: string, reason: string): Order | null {
    return this.updateOrderStatus(orderId, 'cancelled', `Cancellation Reason: ${reason}`);
  }

  public findOrder(query: string, customerPhone?: string): Order | null {
    const normalized = query.toUpperCase();
    const orderMatch = normalized.match(/ORD-\d{4}/);
    if (orderMatch) {
      const found = this.orders.find((o) => o.id.toUpperCase() === orderMatch[0]);
      if (found) return found;
    }

    // Match 4 digits alone
    const fourDigits = query.match(/\b\d{4}\b/);
    if (fourDigits) {
      const found = this.orders.find((o) => o.id.includes(fourDigits[0]));
      if (found) return found;
    }

    // Match by customer phone
    if (customerPhone) {
      const cleanPhone = customerPhone.replace(/\D/g, '');
      const found = this.orders.find((o) => o.customerPhone.replace(/\D/g, '').includes(cleanPhone));
      if (found) return found;
    }

    // Match by name in query
    const words = query.toLowerCase().split(' ');
    for (const order of this.orders) {
      const nameParts = order.customerName.toLowerCase().split(' ');
      if (nameParts.some((part) => words.includes(part) && part.length > 2)) {
        return order;
      }
    }

    return null;
  }

  // Sentiment Analyzer
  public analyzeSentiment(text: string): 'positive' | 'neutral' | 'frustrated' | 'urgent' {
    const lower = text.toLowerCase();
    const urgentKeywords = ['urgent', 'emergency', 'asap', 'immediately', 'lawyer', 'police', 'stolen package', 'fraud'];
    const frustratedKeywords = ['angry', 'terrible', 'worst', 'ridiculous', 'hate', 'bad service', 'unacceptable', 'delayed again', 'scam', 'refund now', 'broken', 'horrible'];
    const positiveKeywords = ['thank you', 'thanks', 'awesome', 'great', 'love it', 'perfect', 'super', 'fast', 'helpful', 'wonderful'];

    if (urgentKeywords.some((k) => lower.includes(k))) return 'urgent';
    if (frustratedKeywords.some((k) => lower.includes(k))) return 'frustrated';
    if (positiveKeywords.some((k) => lower.includes(k))) return 'positive';
    return 'neutral';
  }

  // Main processing pipeline
  public async processMessage(
    userText: string,
    chat: CustomerChat,
    history: ChatMessage[] = []
  ): Promise<BotResponseResult> {
    const lower = userText.toLowerCase().trim();
    const sentiment = this.analyzeSentiment(userText);
    const orderInChat = chat.linkedOrderId ? this.findOrder(chat.linkedOrderId) : null;
    const explicitlyFoundOrder = this.findOrder(userText, chat.phone) || orderInChat;

    // Check for Human Agent Escalation
    const isEscalationKeyword = this.settings.autoHandoffKeywords.some((k) => lower.includes(k.toLowerCase())) ||
      lower.includes('talk to someone') ||
      lower.includes('speak to manager');

    if (isEscalationKeyword || sentiment === 'urgent') {
      const botMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        chatId: chat.id,
        sender: 'bot',
        type: 'human_handoff',
        content: `👨‍💼 *Live Specialist Escalation Confirmed*\n\nI have routed your conversation with priority to our *Senior Logistics & Support Desk*.\n\n• *Estimated wait:* ~90 seconds\n• *Ticket ID:* \`#TK-${Math.floor(100000 + Math.random() * 900000)}\`\n• *Status:* Priority Queue ⚡\n\n_A live agent is reading your conversation context now._`,
        timestamp: this.getCurrentFormattedTime(),
        status: 'delivered',
        buttons: [
          { id: 'btn-cancel-wait', title: '🔙 Back to Bot Menu', payload: 'start_menu', variant: 'secondary' },
          { id: 'btn-faq', title: '📋 Browse FAQ Solutions', payload: 'faq_list', variant: 'primary' },
        ],
        sentiment: 'urgent',
        agentEscalated: true,
      };
      return { message: botMsg, escalated: true };
    }

    // Quick Button Action Payloads
    if (lower === 'track_order' || lower === 'track my order' || lower === 'track') {
      if (explicitlyFoundOrder) {
        return this.generateOrderTrackingResponse(explicitlyFoundOrder, chat.id);
      }
      return {
        message: {
          id: `msg-${Date.now()}`,
          chatId: chat.id,
          sender: 'bot',
          type: 'interactive_buttons',
          content: `🔍 *Live Shipment Lookup*\n\nPlease tap one of your recent orders or type your *Order ID* (e.g., \`ORD-9821\`):`,
          timestamp: this.getCurrentFormattedTime(),
          status: 'delivered',
          buttons: this.orders.slice(0, 3).map((o) => ({
            id: `btn-ord-${o.id}`,
            title: `📦 ${o.id} (${o.status})`,
            payload: `track ${o.id}`,
            variant: 'primary',
          })),
        },
      };
    }

    // Direct Order Tracking Query (e.g., "ORD-9821", "where is ORD-9821", "track my package")
    if (explicitlyFoundOrder && (lower.includes('track') || lower.includes('where') || lower.includes('status') || lower.includes('ord-') || lower.includes('package') || lower.includes('delivery') || lower.includes('arrive'))) {
      return this.generateOrderTrackingResponse(explicitlyFoundOrder, chat.id);
    }

    // Modify Delivery Address Request
    if (lower.includes('change address') || lower.includes('update address') || lower.includes('wrong address') || lower.includes('modify delivery')) {
      if (explicitlyFoundOrder) {
        if (explicitlyFoundOrder.status === 'delivered') {
          return {
            message: {
              id: `msg-${Date.now()}`,
              chatId: chat.id,
              sender: 'bot',
              type: 'text',
              content: `⚠️ *Order #${explicitlyFoundOrder.id} has already been delivered* to:\n*${explicitlyFoundOrder.shippingAddress.street}, ${explicitlyFoundOrder.shippingAddress.city}*.\n\nIf you have not received it or need a package redelivery, please tap below:`,
              timestamp: this.getCurrentFormattedTime(),
              status: 'delivered',
              buttons: [
                { id: 'btn-missing', title: '🚨 Report Missing Package', payload: 'report_missing', variant: 'danger' },
                { id: 'btn-support', title: '👨‍💼 Speak to Agent', payload: 'agent', variant: 'primary' },
              ],
            },
          };
        }

        return {
          message: {
            id: `msg-${Date.now()}`,
            chatId: chat.id,
            sender: 'bot',
            type: 'text',
            content: `🏠 *Update Shipping Address for #${explicitlyFoundOrder.id}*\n\n*Current Destination:* ${explicitlyFoundOrder.shippingAddress.street}, ${explicitlyFoundOrder.shippingAddress.city}, ${explicitlyFoundOrder.shippingAddress.state} ${explicitlyFoundOrder.shippingAddress.postalCode}\n\nTo update your address, reply in this format:\n*Address: 123 New Street, City, State ZIP*`,
            timestamp: this.getCurrentFormattedTime(),
            status: 'delivered',
            buttons: [
              { id: 'btn-confirm-cur', title: '✅ Keep Current Address', payload: `track ${explicitlyFoundOrder.id}`, variant: 'secondary' },
              { id: 'btn-cancel-ord', title: '❌ Cancel Order Instead', payload: `cancel ${explicitlyFoundOrder.id}`, variant: 'danger' },
            ],
          },
        };
      }
    }

    // Handle Address Input pattern
    if (lower.startsWith('address:') || lower.startsWith('new address:')) {
      const newAddressRaw = userText.replace(/^(address:|new address:)/i, '').trim();
      if (explicitlyFoundOrder && newAddressRaw.length > 5) {
        const parts = newAddressRaw.split(',').map((p) => p.trim());
        const street = parts[0] || '100 New Street';
        const city = parts[1] || 'San Francisco';
        const state = parts[2] ? parts[2].split(' ')[0] : 'CA';
        const zip = parts[2] ? parts[2].split(' ')[1] || '94107' : '94107';

        const updated = this.updateOrderAddress(explicitlyFoundOrder.id, street, city, state, zip);

        return {
          message: {
            id: `msg-${Date.now()}`,
            chatId: chat.id,
            sender: 'bot',
            type: 'text',
            content: `🎉 *Shipping Address Updated Successfully!*\n\n• *Order:* #${explicitlyFoundOrder.id}\n• *New Destination:* *${street}, ${city}, ${state} ${zip}*\n• *Status:* Carrier reroute instruction dispatched ⚡\n\nYour courier has been notified of the destination update!`,
            timestamp: this.getCurrentFormattedTime(),
            status: 'delivered',
            buttons: [
              { id: 'btn-retrack', title: '📦 View Updated Tracking', payload: `track ${explicitlyFoundOrder.id}`, variant: 'primary' },
              { id: 'btn-done', title: '✅ All Set, Thank You', payload: 'thank_you', variant: 'secondary' },
            ],
          },
          updatedOrder: updated || undefined,
        };
      }
    }

    // Cancel Order Request
    if (lower.includes('cancel order') || lower.startsWith('cancel ')) {
      if (explicitlyFoundOrder) {
        if (explicitlyFoundOrder.status === 'out_for_delivery' || explicitlyFoundOrder.status === 'delivered') {
          return {
            message: {
              id: `msg-${Date.now()}`,
              chatId: chat.id,
              sender: 'bot',
              type: 'text',
              content: `⚠️ *Order #${explicitlyFoundOrder.id} is already ${explicitlyFoundOrder.status.replace(/_/g, ' ')}* and cannot be instantly cancelled.\n\nHowever, don't worry! You can easily *Refuse delivery* at your door, or initiate a *Free 30-day Return* as soon as it arrives.`,
              timestamp: this.getCurrentFormattedTime(),
              status: 'delivered',
              buttons: [
                { id: 'btn-rma', title: '🔄 Pre-Authorize Return (RMA)', payload: `return ${explicitlyFoundOrder.id}`, variant: 'primary' },
                { id: 'btn-agent', title: '👨‍💼 Speak to Representative', payload: 'agent', variant: 'secondary' },
              ],
            },
          };
        }

        const updated = this.cancelOrder(explicitlyFoundOrder.id, 'Customer requested cancellation via WhatsApp');

        return {
          message: {
            id: `msg-${Date.now()}`,
            chatId: chat.id,
            sender: 'bot',
            type: 'text',
            content: `🛑 *Order #${explicitlyFoundOrder.id} Has Been Cancelled*\n\n• *Refund Amount:* *$${explicitlyFoundOrder.total.toFixed(2)}*\n• *Refund Destination:* Original Payment Method (${explicitlyFoundOrder.paymentMethod})\n• *Timeline:* Refund will appear in 2-3 business days.\n\nA confirmation receipt has been sent to *${explicitlyFoundOrder.customerEmail}*.`,
            timestamp: this.getCurrentFormattedTime(),
            status: 'delivered',
            buttons: [
              { id: 'btn-shop', title: '🛒 Explore New Items', payload: 'browse_catalog', variant: 'primary' },
              { id: 'btn-help', title: '❓ Other Questions', payload: 'start_menu', variant: 'secondary' },
            ],
          },
          updatedOrder: updated || undefined,
        };
      }
    }

    // Returns & Refunds
    if (lower.includes('return') || lower.includes('refund') || lower.includes('exchange') || lower.includes('damaged') || lower.includes('wrong size')) {
      const order = explicitlyFoundOrder;
      if (order && order.status === 'delivered') {
        return {
          message: {
            id: `msg-${Date.now()}`,
            chatId: chat.id,
            sender: 'bot',
            type: 'text',
            content: `🔄 *Instant Return & Exchange Generator*\n\n• *Order:* #${order.id}\n• *Item:* ${order.items[0]?.name}\n• *Policy:* 30-Day Hassle-Free Free Returns\n\n*RMA Return Label #RMA-${Math.floor(100000 + Math.random() * 900000)}* has been generated for you!\n\n📦 *Next Steps:*\n1. Download and print the prepaid shipping label sent to *${order.customerEmail}*.\n2. Drop the package off at any FedEx or USPS location.\n3. Refund of *$${order.total.toFixed(2)}* will be credited automatically upon scan.`,
            timestamp: this.getCurrentFormattedTime(),
            status: 'delivered',
            buttons: [
              { id: 'btn-label', title: '📄 Download Return Label PDF', payload: 'download_label', variant: 'primary' },
              { id: 'btn-exchange', title: '🔄 Exchange for Different Size', payload: 'exchange_request', variant: 'secondary' },
            ],
          },
        };
      }

      return {
        message: {
          id: `msg-${Date.now()}`,
          chatId: chat.id,
          sender: 'bot',
          type: 'text',
          content: `🔄 *ZapFlow Returns & Exchange Policy*\n\n• *30 Days Window:* Return any item within 30 days of delivery.\n• *100% Free Shipping:* We provide a prepaid shipping label.\n• *Instant Refund:* Processed within 48-72 hours to your payment method.\n\nTo start a return right now, reply with your *Order ID* or tap below:`,
          timestamp: this.getCurrentFormattedTime(),
          status: 'delivered',
          buttons: [
            { id: 'btn-ret-1', title: '📦 Return Delivered Order', payload: 'track ORD-7742', variant: 'primary' },
            { id: 'btn-ret-faq', title: '📋 Return FAQ', payload: 'faq_returns', variant: 'secondary' },
          ],
        },
      };
    }

    // Browse Catalog / Products
    if (lower.includes('catalog') || lower.includes('products') || lower.includes('browse') || lower.includes('shop') || lower.includes('buy') || lower.includes('inventory')) {
      return {
        message: {
          id: `msg-${Date.now()}`,
          chatId: chat.id,
          sender: 'bot',
          type: 'product_carousel',
          content: `🛍️ *Featured Best-Sellers on ZapFlow*\n\nHere are our top trending products in stock today with exclusive WhatsApp discount eligibility:`,
          timestamp: this.getCurrentFormattedTime(),
          status: 'delivered',
          productsList: this.products,
          buttons: [
            { id: 'btn-promo', title: '🏷️ View Promo Codes', payload: 'discount_codes', variant: 'primary' },
            { id: 'btn-order', title: '📦 Track My Order', payload: 'track_order', variant: 'secondary' },
          ],
        },
      };
    }

    // Discount Codes
    if (lower.includes('discount') || lower.includes('coupon') || lower.includes('promo') || lower.includes('offer') || lower.includes('deal') || lower.includes('voucher')) {
      const discountList = DISCOUNT_CODES.map((d) => `• *${d.code}* — *${d.discountPercent}% OFF* (${d.description})`).join('\n');
      return {
        message: {
          id: `msg-${Date.now()}`,
          chatId: chat.id,
          sender: 'bot',
          type: 'interactive_buttons',
          content: `🏷️ *Active WhatsApp Exclusive Discounts*\n\n${discountList}\n\n💡 _Tap a code to apply or copy to your checkout!_`,
          timestamp: this.getCurrentFormattedTime(),
          status: 'delivered',
          buttons: DISCOUNT_CODES.map((d) => ({
            id: `btn-code-${d.code}`,
            title: `🎟️ Apply ${d.code} (${d.discountPercent}% Off)`,
            payload: `apply_promo_${d.code}`,
            variant: 'success',
          })),
        },
      };
    }

    // FAQs and Policy Matching
    const matchedFaq = INITIAL_FAQS.find((faq) =>
      faq.keywords.some((k) => lower.includes(k.toLowerCase()))
    );

    if (matchedFaq) {
      return {
        message: {
          id: `msg-${Date.now()}`,
          chatId: chat.id,
          sender: 'bot',
          type: 'text',
          content: `💡 *${matchedFaq.question}*\n\n${matchedFaq.answer}`,
          timestamp: this.getCurrentFormattedTime(),
          status: 'delivered',
          buttons: [
            { id: 'btn-more-faq', title: '❓ Other FAQs', payload: 'faq_list', variant: 'secondary' },
            { id: 'btn-ord-tr', title: '📦 Track an Order', payload: 'track_order', variant: 'primary' },
          ],
        },
      };
    }

    // Greeting / Start Menu
    if (lower.includes('hello') || lower.includes('hi') || lower.includes('hey') || lower.includes('start') || lower.includes('menu') || lower.includes('help')) {
      return {
        message: {
          id: `msg-${Date.now()}`,
          chatId: chat.id,
          sender: 'bot',
          type: 'interactive_buttons',
          content: `👋 *Welcome to ZapFlow Support on WhatsApp!*\n\nI am *SwiftBot*, your 24/7 AI shopping & order concierge ⚡\n\n*How can I assist you today?*`,
          timestamp: this.getCurrentFormattedTime(),
          status: 'delivered',
          buttons: [
            { id: 'btn-m-track', title: '📦 Track My Order', payload: 'track_order', variant: 'primary' },
            { id: 'btn-m-shop', title: '🛍️ Browse Products', payload: 'browse_catalog', variant: 'secondary' },
            { id: 'btn-m-return', title: '🔄 Returns & Refunds', payload: 'returns_help', variant: 'secondary' },
            { id: 'btn-m-promo', title: '🏷️ Active Promos', payload: 'discount_codes', variant: 'success' },
            { id: 'btn-m-agent', title: '👨‍💼 Speak to Human', payload: 'agent', variant: 'secondary' },
          ],
        },
      };
    }

    // Smart Conversational Fallback with helpful action buttons
    return {
      message: {
        id: `msg-${Date.now()}`,
        chatId: chat.id,
        sender: 'bot',
        type: 'interactive_buttons',
        content: `I'm here to make sure you get the exact information you need! ⚡\n\nI can retrieve *live order statuses*, process *refunds & exchanges*, show *product inventory*, or connect you directly with a *human specialist*.\n\n*Choose an option below or send your Order ID:*`,
        timestamp: this.getCurrentFormattedTime(),
        status: 'delivered',
        buttons: [
          { id: 'btn-fb-1', title: '📦 Track Order (ORD-9821)', payload: 'track ORD-9821', variant: 'primary' },
          { id: 'btn-fb-2', title: '🔄 Return & Refund Help', payload: 'returns_help', variant: 'secondary' },
          { id: 'btn-fb-3', title: '🏷️ Discount Codes', payload: 'discount_codes', variant: 'success' },
          { id: 'btn-fb-4', title: '👨‍💼 Talk to Agent', payload: 'agent', variant: 'secondary' },
        ],
      },
    };
  }

  // Generates rich interactive Order Tracking message
  private generateOrderTrackingResponse(order: Order, chatId: string): BotResponseResult {
    const statusEmoji: Record<Order['status'], string> = {
      placed: '📝',
      processing: '⚙️',
      shipped: '🚚',
      out_for_delivery: '🛵',
      delivered: '🎉',
      return_requested: '🔄',
      refunded: '💵',
      cancelled: '🛑',
    };

    const statusTitle: Record<Order['status'], string> = {
      placed: 'Order Placed & Verified',
      processing: 'Processing in Warehouse',
      shipped: 'Shipped & In Transit',
      out_for_delivery: 'Out for Delivery Today!',
      delivered: 'Delivered Successfully',
      return_requested: 'Return RMA Initiated',
      refunded: 'Refund Completed',
      cancelled: 'Order Cancelled',
    };

    const currentCheckpoint = order.checkpoints.find((c) => c.current) || order.checkpoints[order.checkpoints.length - 1];

    let content = `📦 *Live Order Tracking: #${order.id}*\n\n`;
    content += `• *Status:* ${statusEmoji[order.status]} *${statusTitle[order.status]}*\n`;
    content += `• *Estimated Delivery:* *${order.estimatedDelivery}*\n`;
    content += `• *Courier:* ${order.courier.name} (\`${order.courier.trackingNumber}\`)\n`;
    if (order.courier.etaWindow) {
      content += `• *Driver ETA:* *${order.courier.etaWindow}*\n`;
    }
    if (currentCheckpoint) {
      content += `• *Latest Checkpoint:* ${currentCheckpoint.description} _(${currentCheckpoint.location})_\n`;
    }
    content += `• *Shipping To:* ${order.shippingAddress.street}, ${order.shippingAddress.city}, ${order.shippingAddress.state}\n`;
    content += `• *Items (${order.items.length}):* ${order.items.map((i) => `${i.name} (x${i.quantity})`).join(', ')}`;

    const buttons: InteractiveButton[] = [];

    if (order.status === 'out_for_delivery') {
      buttons.push({ id: 'btn-driver', title: '📞 Contact Courier Driver', payload: `driver_call_${order.id}`, variant: 'primary' });
      buttons.push({ id: 'btn-gate', title: '🚪 Gate / Drop-off Note', payload: `gate_note_${order.id}`, variant: 'secondary' });
    } else if (order.status === 'shipped' || order.status === 'processing') {
      buttons.push({ id: 'btn-chg-addr', title: '🏠 Change Delivery Address', payload: `change address for ${order.id}`, variant: 'secondary' });
      if (order.canCancel) {
        buttons.push({ id: 'btn-cancel', title: '❌ Cancel Order', payload: `cancel ${order.id}`, variant: 'danger' });
      }
    } else if (order.status === 'delivered') {
      buttons.push({ id: 'btn-invoice', title: '📄 Download Invoice PDF', payload: `invoice_${order.id}`, variant: 'secondary' });
      buttons.push({ id: 'btn-return', title: '🔄 Return or Exchange Item', payload: `return ${order.id}`, variant: 'primary' });
    }

    buttons.push({ id: 'btn-agent', title: '👨‍💼 Speak to Agent', payload: 'agent', variant: 'secondary' });

    const message: ChatMessage = {
      id: `msg-${Date.now()}`,
      chatId,
      sender: 'bot',
      type: 'order_card',
      content,
      timestamp: this.getCurrentFormattedTime(),
      status: 'delivered',
      orderId: order.id,
      orderData: order,
      buttons,
    };

    return {
      message,
      updatedOrder: order,
    };
  }

  private getCurrentFormattedTime(): string {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
}

export const botEngine = new WhatsAppBotEngine();
