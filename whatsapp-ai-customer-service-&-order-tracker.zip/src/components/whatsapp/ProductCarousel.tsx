import React from 'react';
import { ShoppingCart, Star, ArrowRight } from 'lucide-react';
import { Product } from '../../types';

interface ProductCarouselProps {
  products: Product[];
  onSelectProduct?: (product: Product) => void;
}

export const ProductCarousel: React.FC<ProductCarouselProps> = ({ products, onSelectProduct }) => {
  return (
    <div className="my-2 max-w-lg w-full">
      <div className="flex gap-3 overflow-x-auto pb-2 pt-1 no-scrollbar snap-x">
        {products.map((product) => (
          <div
            key={product.id}
            className="snap-center shrink-0 w-64 bg-white/10 backdrop-blur-2xl border border-white/15 rounded-2xl overflow-hidden shadow-xl flex flex-col justify-between transition-all hover:scale-[1.02] text-white"
          >
            {/* Image & Discount Badge */}
            <div className="relative h-32 bg-white/5">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
              {product.originalPrice && (
                <div className="absolute top-2.5 left-2.5 bg-red-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-md backdrop-blur-xs border border-red-400/30">
                  {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                </div>
              )}
              <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-md text-white text-[10px] font-medium px-2 py-0.5 rounded-lg flex items-center gap-1 border border-white/10">
                <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                <span>{product.rating} ({product.reviewsCount})</span>
              </div>
            </div>

            {/* Content */}
            <div className="p-3.5 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-300">
                  {product.category}
                </span>
                <h4 className="text-xs font-bold text-white line-clamp-2 mt-0.5">
                  {product.name}
                </h4>
                <p className="text-[11px] text-white/60 line-clamp-2 mt-1">
                  {product.description}
                </p>
              </div>

              {/* Price & Stock */}
              <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-white font-mono">
                    ${product.price.toFixed(2)}
                  </div>
                  {product.originalPrice && (
                    <span className="text-[11px] text-white/40 line-through">
                      ${product.originalPrice.toFixed(2)}
                    </span>
                  )}
                </div>

                <button
                  onClick={() => onSelectProduct && onSelectProduct(product)}
                  className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl text-xs font-medium flex items-center gap-1 shadow-lg shadow-indigo-500/20 transition-all border border-indigo-400/30"
                >
                  <span>Inquire</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
