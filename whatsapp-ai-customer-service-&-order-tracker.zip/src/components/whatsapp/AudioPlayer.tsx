import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Mic } from 'lucide-react';

interface AudioPlayerProps {
  duration?: number;
  isBot?: boolean;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ duration = 14, isBot = false }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [speed, setSpeed] = useState<1 | 1.5 | 2>(1);
  const intervalRef = useRef<any>(null);

  // Generate random static waveform bar heights
  const bars = [40, 65, 80, 45, 90, 100, 70, 50, 85, 95, 60, 40, 75, 90, 60, 80, 100, 50, 70, 40, 85, 60, 95, 75, 50, 90, 65, 45];

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 0.1 * speed;
        });
      }, 100);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPlaying, speed, duration]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const cycleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (speed === 1) setSpeed(1.5);
    else if (speed === 1.5) setSpeed(2);
    else setSpeed(1);
  };

  const progressPercent = Math.min(100, (currentTime / duration) * 100);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="flex items-center gap-3 py-1 px-1 min-w-[240px] max-w-[280px] text-white">
      {/* Play/Pause Button */}
      <button
        onClick={togglePlay}
        className="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center transition-all shadow-md border border-white/20 text-white"
      >
        {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current translate-x-0.5" />}
      </button>

      {/* Waveform & Scrubber */}
      <div className="flex-1 flex flex-col justify-center">
        <div className="flex items-center gap-[2px] h-7 cursor-pointer" onClick={() => setCurrentTime((progressPercent / 100) * duration)}>
          {bars.map((height, i) => {
            const barPercent = (i / bars.length) * 100;
            const isFilled = barPercent <= progressPercent;
            return (
              <div
                key={i}
                className={`w-[3px] rounded-full transition-all duration-75 ${
                  isFilled ? 'bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]' : 'bg-white/25'
                }`}
                style={{ height: `${Math.max(20, height * 0.26)}px` }}
              />
            );
          })}
        </div>

        {/* Time & Mic indicator */}
        <div className="flex justify-between items-center text-[11px] text-white/60 mt-0.5 font-mono">
          <span>{formatTime(isPlaying ? currentTime : duration)}</span>
          <div className="flex items-center gap-1">
            <Mic className="w-3 h-3 text-green-400" />
            <span className="text-[10px] text-white/70 font-sans font-medium">Voice Note</span>
          </div>
        </div>
      </div>

      {/* Speed Multiplier */}
      <button
        onClick={cycleSpeed}
        className="px-2 py-0.5 text-[10px] font-bold rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/10 transition-colors backdrop-blur-md"
      >
        {speed}x
      </button>
    </div>
  );
};
