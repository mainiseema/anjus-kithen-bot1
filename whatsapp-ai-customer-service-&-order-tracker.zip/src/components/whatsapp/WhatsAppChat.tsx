import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Paperclip,
  Smile,
  Mic,
  MoreVertical,
  Phone,
  Video,
  Search,
  Check,
  CheckCheck,
  Sparkles,
  Info,
  RotateCcw,
  Image as ImageIcon,
  MapPin,
  FileText,
  Trash2,
  Download,
  AlertTriangle,
  ArrowLeft,
  X,
} from 'lucide-react';
import { ChatMessage, CustomerChat, Order, Product } from '../../types';
import { DEFAULT_BOT_SETTINGS } from '../../data/mockData';
import { OrderTrackingCard } from './OrderTrackingCard';
import { ProductCarousel } from './ProductCarousel';
import { AudioPlayer } from './AudioPlayer';
import { ContactInfoModal } from './ContactInfoModal';
import confetti from 'canvas-confetti';

interface WhatsAppChatProps {
  chat: CustomerChat;
  messages: ChatMessage[];
  orders: Order[];
  onSendMessage: (text: string, type?: ChatMessage['type'], extraData?: any) => void;
  isTyping: boolean;
  onClearChat: () => void;
  onBackToList?: () => void;
}

export const WhatsAppChat: React.FC<WhatsAppChatProps> = ({
  chat,
  messages,
  orders,
  onSendMessage,
  isTyping,
  onClearChat,
  onBackToList,
}) => {
  const [inputText, setInputText] = useState('');
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showMenuDropdown, setShowMenuDropdown] = useState(false);
  const [showCallModal, setShowCallModal] = useState<'audio' | 'video' | null>(null);
  const [recordingAudio, setRecordingAudio] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recordIntervalRef = useRef<any>(null);

  // Auto scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Voice recording timer simulation
  useEffect(() => {
    if (recordingAudio) {
      setRecordSeconds(0);
      recordIntervalRef.current = setInterval(() => {
        setRecordSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
    }
    return () => {
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
    };
  }, [recordingAudio]);

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    onSendMessage(inputText.trim());
    setInputText('');
    setShowAttachMenu(false);
  };

  const handleQuickPrompt = (prompt: string) => {
    onSendMessage(prompt);
  };

  const handleFinishVoiceRecord = () => {
    setRecordingAudio(false);
    onSendMessage('Simulated WhatsApp Voice Note', 'audio_note', { audioDuration: Math.max(3, recordSeconds) });
  };

  const handleCancelVoiceRecord = () => {
    setRecordingAudio(false);
    setRecordSeconds(0);
  };

  const handleSendDamagedItemPhoto = () => {
    setShowAttachMenu(false);
    onSendMessage(
      'Attached photo of received item for return/replacement assessment.',
      'image',
      {
        mediaUrl: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=600&auto=format&fit=crop&q=80',
        mediaCaption: 'Photo of item condition for return assessment',
      }
    );
  };

  const handleSendLocation = () => {
    setShowAttachMenu(false);
    onSendMessage('📍 Shared Drop-off Location Pin', 'location', {
      latitude: 40.7128,
      longitude: -74.006,
      locationName: 'Front Porch / Parcel Drop Lockbox, 742 Evergreen Terrace',
    });
  };

  const handleSendInvoiceRequest = () => {
    setShowAttachMenu(false);
    onSendMessage('Please send my official invoice PDF for my recent purchase.');
  };

  const handleSelectProduct = (product: Product) => {
    onSendMessage(`I am interested in purchasing the *${product.name}* ($${product.price}). How quickly can it ship?`);
  };

  const linkedOrder = chat.linkedOrderId ? orders.find((o) => o.id === chat.linkedOrderId) : null;

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0f172a]/70 backdrop-blur-2xl relative overflow-hidden text-white select-none">
      {/* Top Chat Header */}
      <div className="h-16 sm:h-20 bg-white/5 backdrop-blur-2xl border-b border-white/10 px-4 sm:px-6 flex items-center justify-between shrink-0 z-20">
        <div className="flex items-center gap-3">
          {onBackToList && (
            <button
              onClick={onBackToList}
              className="md:hidden p-2 hover:bg-white/10 rounded-xl text-white/70"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}

          {/* Customer Avatar & Status */}
          <div
            onClick={() => setShowInfoModal(true)}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative">
              <img
                src={chat.avatar}
                alt={chat.name}
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl object-cover border border-white/15 shadow-md group-hover:border-indigo-400 transition-colors"
                onError={(e: any) => {
                  e.target.src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80';
                }}
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-green-500 border-2 border-[#0f172a]" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-sm sm:text-base text-white group-hover:text-indigo-300 transition-colors">
                  {chat.name}
                </h2>
                {chat.status === 'human_agent' ? (
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold border border-amber-400/30">
                    Live Agent
                  </span>
                ) : (
                  <span className="text-[10px] bg-green-500/20 text-green-300 px-2 py-0.5 rounded-full font-bold border border-green-400/30">
                    AI Active
                  </span>
                )}
              </div>
              <p className="text-[11px] text-green-400 flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                Active on WhatsApp • {chat.phone}
              </p>
            </div>
          </div>
        </div>

        {/* Header Action Tools */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={() => setShowCallModal('video')}
            className="p-2.5 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all text-white/80 hover:text-white"
            title="Start Video Consultation"
          >
            <Video className="w-4 h-4" />
          </button>

          <button
            onClick={() => setShowCallModal('audio')}
            className="p-2.5 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all text-white/80 hover:text-white"
            title="Start WhatsApp Voice Call"
          >
            <Phone className="w-4 h-4" />
          </button>

          <button
            onClick={() => setShowInfoModal(true)}
            className="p-2.5 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all text-white/80 hover:text-white"
            title="Customer & Order Details"
          >
            <Info className="w-4 h-4" />
          </button>

          {/* Menu Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowMenuDropdown(!showMenuDropdown)}
              className="p-2.5 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all text-white/80 hover:text-white"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {showMenuDropdown && (
              <div className="absolute right-0 top-12 w-48 bg-[#1e1b4b]/95 backdrop-blur-2xl rounded-2xl shadow-2xl border border-white/10 py-1.5 z-50 text-xs text-white">
                <button
                  onClick={() => {
                    setShowInfoModal(true);
                    setShowMenuDropdown(false);
                  }}
                  className="w-full px-4 py-2 text-left hover:bg-white/10 flex items-center gap-2"
                >
                  <Info className="w-3.5 h-3.5" /> Customer Profile
                </button>
                <button
                  onClick={() => {
                    handleQuickPrompt('browse_catalog');
                    setShowMenuDropdown(false);
                  }}
                  className="w-full px-4 py-2 text-left hover:bg-white/10 flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" /> Show Product Catalog
                </button>
                <button
                  onClick={() => {
                    handleQuickPrompt('discount_codes');
                    setShowMenuDropdown(false);
                  }}
                  className="w-full px-4 py-2 text-left hover:bg-white/10 flex items-center gap-2"
                >
                  🏷️ Active Discounts
                </button>
                <button
                  onClick={() => {
                    onClearChat();
                    setShowMenuDropdown(false);
                  }}
                  className="w-full px-4 py-2 text-left text-red-400 hover:bg-white/10 flex items-center gap-2"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Clear Chat History
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 relative">
        {/* End-to-End Encryption Security Banner */}
        <div className="flex justify-center">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl px-4 py-2 max-w-md text-center shadow-lg">
            <p className="text-[11px] text-white/50 leading-tight">
              🔒 Messages and calls are end-to-end encrypted. AI Assistant <span className="font-semibold text-green-400">SwiftBot</span> is active.
            </p>
          </div>
        </div>

        {/* Message bubbles */}
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';

          return (
            <div
              key={msg.id}
              className={`flex flex-col gap-1 ${isUser ? 'items-start max-w-[85%] sm:max-w-[75%]' : 'items-end max-w-[85%] sm:max-w-[75%] ml-auto'}`}
            >
              {/* Message Content Container */}
              <div
                className={`p-4 rounded-2xl shadow-lg transition-all ${
                  isUser
                    ? 'bg-white/10 backdrop-blur-md border border-white/10 text-white rounded-tl-none leading-relaxed text-sm'
                    : 'bg-indigo-500/80 backdrop-blur-md border border-indigo-400/30 text-white rounded-tr-none shadow-indigo-500/15 leading-relaxed text-sm'
                }`}
              >
                {/* Media Image */}
                {msg.type === 'image' && msg.mediaUrl && (
                  <div className="mb-2 rounded-xl overflow-hidden border border-white/10">
                    <img
                      src={msg.mediaUrl}
                      alt="WhatsApp Attachment"
                      className="w-full max-h-60 object-cover"
                    />
                    {msg.mediaCaption && (
                      <div className="p-2 text-xs bg-black/40 text-white/80">
                        {msg.mediaCaption}
                      </div>
                    )}
                  </div>
                )}

                {/* Location Pin */}
                {msg.type === 'location' && (
                  <div className="mb-2 p-3 bg-white/10 rounded-xl border border-white/10 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-red-500 flex items-center justify-center text-white shrink-0 shadow-md">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Live Location Shared</div>
                      <div className="text-[11px] text-white/70">{msg.locationName || '742 Evergreen Terrace'}</div>
                    </div>
                  </div>
                )}

                {/* Voice Note */}
                {msg.type === 'audio_note' && (
                  <div className="mb-1">
                    <AudioPlayer durationSeconds={msg.audioDuration || 6} />
                  </div>
                )}

                {/* Text Body with formatted WhatsApp Markdown */}
                {msg.type !== 'audio_note' && (
                  <div className="whitespace-pre-wrap font-sans">
                    {msg.content.split('\n').map((line, idx) => {
                      // Formatting simple bold (*word*)
                      const boldFormatted = line.replace(/\*(.*?)\*/g, '<strong>$1</strong>');
                      return (
                        <div
                          key={idx}
                          dangerouslySetInnerHTML={{ __html: boldFormatted }}
                          className="min-h-[1.2em]"
                        />
                      );
                    })}
                  </div>
                )}

                {/* Embedded Rich Order Tracking Card */}
                {msg.type === 'order_card' && msg.orderData && (
                  <div className="mt-3">
                    <OrderTrackingCard
                      order={msg.orderData}
                      onActionClick={(payload) => handleQuickPrompt(payload)}
                    />
                  </div>
                )}

                {/* Product Catalog Carousel */}
                {msg.type === 'product_list' && msg.products && (
                  <div className="mt-3">
                    <ProductCarousel
                      products={msg.products}
                      onSelectProduct={handleSelectProduct}
                    />
                  </div>
                )}

                {/* WhatsApp Interactive Action Buttons */}
                {msg.buttons && msg.buttons.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-white/15 flex flex-wrap gap-2">
                    {msg.buttons.map((btn) => (
                      <button
                        key={btn.id}
                        onClick={() => handleQuickPrompt(btn.payload)}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md ${
                          btn.variant === 'primary'
                            ? 'bg-white/20 hover:bg-white/30 text-white border border-white/20'
                            : btn.variant === 'success'
                            ? 'bg-green-500 hover:bg-green-600 text-white border border-green-400/30'
                            : 'bg-white/10 hover:bg-white/20 text-white/90 border border-white/10'
                        }`}
                      >
                        {btn.title}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Timestamp & Delivery Checks */}
              <div className={`flex items-center gap-1 text-[10px] text-white/40 px-1 ${isUser ? 'self-start' : 'self-end'}`}>
                <span>{isUser ? 'Customer' : 'SwiftBot AI'}</span>
                <span>•</span>
                <span>{msg.timestamp}</span>
                {isUser && (
                  <span className="ml-0.5">
                    {msg.status === 'read' ? (
                      <CheckCheck className="w-3.5 h-3.5 text-blue-400 inline" />
                    ) : msg.status === 'delivered' ? (
                      <CheckCheck className="w-3.5 h-3.5 text-white/40 inline" />
                    ) : (
                      <Check className="w-3.5 h-3.5 text-white/40 inline" />
                    )}
                  </span>
                )}
              </div>
            </div>
          );
        })}

        {/* AI Typing Indicator */}
        {isTyping && (
          <div className="flex items-center gap-2 bg-indigo-500/70 backdrop-blur-md border border-indigo-400/30 rounded-2xl rounded-tr-none px-4 py-3 max-w-[120px] ml-auto shadow-lg shadow-indigo-500/20">
            <span className="text-xs text-white/80 font-medium mr-1">Typing</span>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-bounce [animation-delay:-0.3s]" />
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-bounce [animation-delay:-0.15s]" />
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Inquiries Bar */}
      <div className="px-4 py-2.5 bg-white/[0.03] border-t border-white/10 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
        <span className="text-[10px] uppercase font-bold tracking-wider text-white/40 shrink-0">
          Quick Inquiries:
        </span>
        <button
          onClick={() => handleQuickPrompt('track ORD-9821')}
          className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium border border-white/10 backdrop-blur-md whitespace-nowrap transition-all"
        >
          📦 Track #ORD-9821
        </button>
        <button
          onClick={() => handleQuickPrompt('returns_help')}
          className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium border border-white/10 backdrop-blur-md whitespace-nowrap transition-all"
        >
          🔄 Returns & Refunds
        </button>
        <button
          onClick={() => handleQuickPrompt('discount_codes')}
          className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium border border-white/10 backdrop-blur-md whitespace-nowrap transition-all"
        >
          🏷️ Active Promos
        </button>
        <button
          onClick={() => handleQuickPrompt('browse_catalog')}
          className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium border border-white/10 backdrop-blur-md whitespace-nowrap transition-all"
        >
          🛒 Browse Catalog
        </button>
        <button
          onClick={() => handleQuickPrompt('agent')}
          className="px-3 py-1 bg-indigo-500/80 hover:bg-indigo-600 text-white rounded-xl text-xs font-medium border border-indigo-400/30 backdrop-blur-md whitespace-nowrap transition-all shadow-md shadow-indigo-500/20"
        >
          👨‍💼 Human Agent
        </button>
      </div>

      {/* Attachment Popover */}
      {showAttachMenu && (
        <div className="absolute bottom-20 left-4 bg-[#1e1b4b]/95 backdrop-blur-2xl border border-white/10 rounded-[2rem] p-3 shadow-2xl flex items-center gap-3 z-40 text-xs">
          <button
            onClick={handleSendDamagedItemPhoto}
            className="flex flex-col items-center gap-1.5 p-2.5 hover:bg-white/10 rounded-2xl transition-colors text-purple-300"
          >
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-400/30 flex items-center justify-center text-purple-300 shadow-md">
              <ImageIcon className="w-5 h-5" />
            </div>
            <span className="text-[10px] text-white">Item Photo</span>
          </button>

          <button
            onClick={handleSendLocation}
            className="flex flex-col items-center gap-1.5 p-2.5 hover:bg-white/10 rounded-2xl transition-colors text-emerald-300"
          >
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300 shadow-md">
              <MapPin className="w-5 h-5" />
            </div>
            <span className="text-[10px] text-white">Drop-off Pin</span>
          </button>

          <button
            onClick={handleSendInvoiceRequest}
            className="flex flex-col items-center gap-1.5 p-2.5 hover:bg-white/10 rounded-2xl transition-colors text-blue-300"
          >
            <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-300 shadow-md">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-[10px] text-white">Invoice PDF</span>
          </button>
        </div>
      )}

      {/* Bottom Message Input Bar */}
      <div className="p-3 sm:p-4 bg-white/5 backdrop-blur-2xl border-t border-white/10 shrink-0">
        {recordingAudio ? (
          <div className="flex items-center justify-between bg-red-500/20 border border-red-400/30 rounded-2xl p-3 backdrop-blur-md">
            <div className="flex items-center gap-2 text-red-300 text-xs font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              Recording WhatsApp Voice Note: {recordSeconds}s
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCancelVoiceRecord}
                className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleFinishVoiceRecord}
                className="px-3.5 py-1.5 bg-green-500 hover:bg-green-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-green-500/20"
              >
                Send Voice
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSend} className="flex items-center gap-2 sm:gap-3">
            <button
              type="button"
              onClick={() => setShowAttachMenu(!showAttachMenu)}
              className="p-3 bg-white/5 hover:bg-white/15 border border-white/10 rounded-2xl text-white/80 hover:text-white transition-all backdrop-blur-md shrink-0"
              title="Attach media or drop pin"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <div className="flex-1 relative">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Type customer inquiry, tracking #, or promo question..."
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-3.5 pl-4 pr-10 text-sm text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 backdrop-blur-md transition-all"
              />
              <button
                type="button"
                onClick={() => setInputText((prev) => prev + ' 📦')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
              >
                <Smile className="w-4 h-4" />
              </button>
            </div>

            {inputText.trim() ? (
              <button
                type="submit"
                className="p-3.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-500/25 border border-indigo-400/30 transition-all shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setRecordingAudio(true)}
                className="p-3.5 bg-white/5 hover:bg-white/15 border border-white/10 rounded-2xl text-white/80 hover:text-white transition-all backdrop-blur-md shrink-0"
                title="Hold to Record WhatsApp Audio"
              >
                <Mic className="w-4 h-4" />
              </button>
            )}
          </form>
        )}
      </div>

      {/* Customer Profile Details Modal */}
      <ContactInfoModal
        isOpen={showInfoModal}
        onClose={() => setShowInfoModal(false)}
        chat={chat}
        linkedOrder={linkedOrder || undefined}
        onQuickAction={(payload) => {
          setShowInfoModal(false);
          handleQuickPrompt(payload);
        }}
      />

      {/* Simulated Video / Voice Call Modal */}
      {showCallModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1e1b4b]/95 backdrop-blur-2xl rounded-[2rem] max-w-sm w-full p-6 text-center border border-white/10 shadow-2xl text-white">
            <div className="w-20 h-20 rounded-full mx-auto mb-4 border-2 border-green-400 overflow-hidden shadow-lg shadow-green-500/20">
              <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover" />
            </div>
            <h3 className="font-bold text-lg text-white">{chat.name}</h3>
            <p className="text-xs text-green-400 font-medium animate-pulse mt-1">
              WhatsApp {showCallModal === 'video' ? 'Video' : 'Voice'} Calling...
            </p>
            <div className="mt-8 flex items-center justify-center gap-4">
              <button
                onClick={() => setShowCallModal(null)}
                className="w-12 h-12 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow-lg transition-transform active:scale-95"
              >
                <Phone className="w-5 h-5 rotate-[135deg]" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
