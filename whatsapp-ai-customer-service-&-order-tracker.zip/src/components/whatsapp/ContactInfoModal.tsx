import React from 'react';
import {
  X,
  CheckCircle2,
  Phone,
  Mail,
  MapPin,
  Clock,
  ShieldCheck,
  Package,
  Store,
  DollarSign,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { DEFAULT_BOT_SETTINGS, INITIAL_PRODUCTS } from '../../data/mockData';
import { CustomerChat, Order } from '../../types';

interface ContactInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  chat?: CustomerChat;
  linkedOrder?: Order;
  onQuickAction?: (payload: string) => void;
}

export const ContactInfoModal: React.FC<ContactInfoModalProps> = ({
  isOpen,
  onClose,
  chat,
  linkedOrder,
  onQuickAction,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#1e1b4b]/95 backdrop-blur-2xl rounded-[2rem] max-w-md w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-white/15 text-white animate-in fade-in zoom-in-95 duration-150">
        {/* Header with Cover */}
        <div className="relative bg-gradient-to-r from-indigo-600/80 to-purple-600/80 backdrop-blur-md h-32 p-4 text-white flex justify-between items-start border-b border-white/10">
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center transition-colors backdrop-blur-sm border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-md border border-white/20">
            <CheckCircle2 className="w-3.5 h-3.5 text-green-400" />
            <span>Official WhatsApp Business</span>
          </div>
        </div>

        {/* Profile Avatar & Title */}
        <div className="px-6 pb-6 pt-0 relative">
          <div className="-mt-14 mb-4 flex items-end justify-between">
            <div className="w-24 h-24 rounded-2xl bg-white/10 backdrop-blur-md p-1 shadow-2xl border-2 border-indigo-400 overflow-hidden">
              {chat?.avatar ? (
                <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover rounded-xl" />
              ) : (
                <div className="w-full h-full rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-3xl font-black">
                  ⚡
                </div>
              )}
            </div>
            <div className="text-right">
              <div className="text-xs text-white/50">Response Speed</div>
              <div className="text-xs font-bold text-green-400">⚡ Instant (&lt;1 sec)</div>
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">
                {chat ? chat.name : DEFAULT_BOT_SETTINGS.businessName}
              </h2>
              <CheckCircle2 className="w-4 h-4 text-green-400 fill-green-400/20" />
            </div>
            <p className="text-xs text-white/60">
              {chat ? `${chat.phone} • Verified Customer` : 'Electronics • Home Living • 24/7 AI Order Support'}
            </p>
          </div>

          {/* Customer Profile Metrics if chat provided */}
          {chat && (
            <div className="mt-4 p-4 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 space-y-2.5">
              <div className="text-[10px] font-bold uppercase tracking-widest text-indigo-300">
                Customer Profile
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-white/40 block text-[11px]">Total Orders</span>
                  <span className="font-bold text-white text-sm">{chat.totalOrdersCount || 2} orders</span>
                </div>
                <div>
                  <span className="text-white/40 block text-[11px]">Lifetime Spend</span>
                  <span className="font-bold text-green-400 text-sm font-mono">${(chat.lifetimeValue || 299).toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Business & Support Details */}
          <div className="mt-4 p-4 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 space-y-3 text-xs text-white/80">
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-white">Store Address</div>
                <div className="text-white/60">{DEFAULT_BOT_SETTINGS.businessAddress}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-white">Operating Hours</div>
                <div className="text-white/60">{DEFAULT_BOT_SETTINGS.businessHours}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <ShieldCheck className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-white">Customer Guarantee</div>
                <div className="text-white/60">
                  30-Day Hassle-Free Free Returns & 2-Year Manufacturer Warranty
                </div>
              </div>
            </div>
          </div>

          {/* Quick Prompts */}
          {onQuickAction && (
            <div className="mt-4 flex gap-2">
              <button
                onClick={() => onQuickAction('track_order')}
                className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium border border-white/10 transition-colors backdrop-blur-md"
              >
                📦 Track Order
              </button>
              <button
                onClick={() => onQuickAction('returns_help')}
                className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium border border-white/10 transition-colors backdrop-blur-md"
              >
                🔄 Start Return
              </button>
            </div>
          )}

          {/* Close button */}
          <button
            onClick={onClose}
            className="mt-5 w-full py-3 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-500/25 border border-indigo-400/30"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
