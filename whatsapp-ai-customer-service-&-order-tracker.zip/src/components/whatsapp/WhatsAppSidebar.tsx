import React, { useState } from 'react';
import {
  Search,
  Plus,
  Package,
  AlertCircle,
  User,
  Sparkles,
} from 'lucide-react';
import { CustomerChat, Order } from '../../types';

interface WhatsAppSidebarProps {
  chats: CustomerChat[];
  activeChatId: string;
  onSelectChat: (chatId: string) => void;
  onAddNewChat: (newChat: Partial<CustomerChat>) => void;
  orders: Order[];
}

export const WhatsAppSidebar: React.FC<WhatsAppSidebarProps> = ({
  chats,
  activeChatId,
  onSelectChat,
  onAddNewChat,
  orders,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'unread' | 'tracking' | 'escalated'>('all');
  const [showNewChatModal, setShowNewChatModal] = useState(false);

  // New Chat Form State
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [selectedOrderId, setSelectedOrderId] = useState('');

  const filteredChats = chats.filter((chat) => {
    const matchesSearch =
      chat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      chat.phone.includes(searchQuery) ||
      (chat.linkedOrderId && chat.linkedOrderId.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (activeTab === 'unread') return chat.unreadCount > 0;
    if (activeTab === 'tracking') return !!chat.linkedOrderId;
    if (activeTab === 'escalated') return chat.status === 'human_agent';
    return true;
  });

  const handleCreateChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomerName.trim()) return;

    onAddNewChat({
      name: newCustomerName,
      phone: newCustomerPhone || `+1 (555) ${Math.floor(100 + Math.random() * 900)}-${Math.floor(1000 + Math.random() * 9000)}`,
      avatar: `https://images.unsplash.com/photo-${1530000000000 + Math.floor(Math.random() * 500000)}?w=150&auto=format&fit=crop&q=80`,
      linkedOrderId: selectedOrderId || undefined,
      lastMessage: 'Chat started. How can I help you today?',
      lastMessageTime: 'Just now',
      unreadCount: 0,
      status: 'bot_handling',
      tags: ['Custom Test Chat'],
      totalOrdersCount: selectedOrderId ? 1 : 0,
      lifetimeValue: selectedOrderId ? 199 : 0,
      isOnline: true,
    });

    setNewCustomerName('');
    setNewCustomerPhone('');
    setSelectedOrderId('');
    setShowNewChatModal(false);
  };

  return (
    <div className="w-full md:w-80 lg:w-96 flex flex-col bg-white/[0.03] backdrop-blur-2xl border-r border-white/10 h-full select-none text-white">
      {/* Header bar */}
      <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-green-500 flex items-center justify-center text-white font-bold text-sm shadow-lg shadow-green-500/20">
            ⚡
          </div>
          <div>
            <h1 className="font-bold text-sm text-white leading-tight">
              Customer Chats
            </h1>
            <p className="text-[11px] text-green-400 font-medium flex items-center gap-1.5 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              Bot Active 24/7
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowNewChatModal(true)}
          className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl text-xs font-medium flex items-center gap-1.5 shadow-lg shadow-indigo-500/20 transition-all border border-indigo-400/30"
          title="Create New Test Chat"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">New Chat</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="p-3 bg-white/[0.02] border-b border-white/10 space-y-2.5">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-white/40 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            placeholder="Search name, phone, or #ORD-..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-3 py-2 bg-white/5 border border-white/10 text-xs text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 placeholder-white/30 backdrop-blur-md transition-all"
          />
        </div>

        {/* Quick Filter Tabs */}
        <div className="flex items-center gap-1.5 text-[11px] overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1 rounded-xl font-medium transition-all shrink-0 ${
              activeTab === 'all'
                ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/20 border border-indigo-400/30'
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
            }`}
          >
            All ({chats.length})
          </button>
          <button
            onClick={() => setActiveTab('tracking')}
            className={`px-3 py-1 rounded-xl font-medium transition-all shrink-0 flex items-center gap-1.5 ${
              activeTab === 'tracking'
                ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/20 border border-indigo-400/30'
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
            }`}
          >
            <Package className="w-3 h-3" />
            Orders
          </button>
          <button
            onClick={() => setActiveTab('unread')}
            className={`px-3 py-1 rounded-xl font-medium transition-all shrink-0 ${
              activeTab === 'unread'
                ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/20 border border-indigo-400/30'
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
            }`}
          >
            Unread
          </button>
          <button
            onClick={() => setActiveTab('escalated')}
            className={`px-3 py-1 rounded-xl font-medium transition-all shrink-0 flex items-center gap-1.5 ${
              activeTab === 'escalated'
                ? 'bg-amber-500/90 text-white shadow-md shadow-amber-500/20 border border-amber-400/30'
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
            }`}
          >
            <AlertCircle className="w-3 h-3 text-amber-400" />
            Agent
          </button>
        </div>
      </div>

      {/* Chats List */}
      <div className="flex-1 overflow-y-auto divide-y divide-white/5">
        {filteredChats.length === 0 ? (
          <div className="p-8 text-center text-white/40 text-xs">
            <User className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p>No conversations found</p>
          </div>
        ) : (
          filteredChats.map((chat) => {
            const isActive = chat.id === activeChatId;
            const linkedOrder = chat.linkedOrderId ? orders.find((o) => o.id === chat.linkedOrderId) : null;

            return (
              <div
                key={chat.id}
                onClick={() => onSelectChat(chat.id)}
                className={`p-3.5 flex items-start gap-3 cursor-pointer transition-all relative ${
                  isActive
                    ? 'bg-white/10 border-l-4 border-indigo-400 backdrop-blur-md'
                    : 'hover:bg-white/5'
                }`}
              >
                {/* Avatar with Online Badge */}
                <div className="relative shrink-0">
                  <img
                    src={chat.avatar}
                    alt={chat.name}
                    className="w-12 h-12 rounded-2xl object-cover border border-white/15 shadow-md"
                    onError={(e: any) => {
                      e.target.src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80';
                    }}
                  />
                  {chat.isOnline && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-green-500 border-2 border-[#0f172a] shadow-sm" />
                  )}
                </div>

                {/* Info & Last Message */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-white truncate">
                      {chat.name}
                    </span>
                    <span className="text-[10px] text-white/40 shrink-0 ml-1">
                      {chat.lastMessageTime}
                    </span>
                  </div>

                  <div className="text-[11px] text-white/60 truncate mt-0.5">
                    {chat.lastMessage}
                  </div>

                  {/* Badges */}
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    {chat.linkedOrderId && (
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 font-mono font-semibold flex items-center gap-1">
                        <Package className="w-2.5 h-2.5" />
                        {chat.linkedOrderId}
                      </span>
                    )}

                    {chat.status === 'human_agent' && (
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-400/30 text-amber-300 font-semibold">
                        Agent Queue
                      </span>
                    )}

                    {linkedOrder && (
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-white/10 border border-white/10 text-white/70 capitalize">
                        {linkedOrder.status.replace(/_/g, ' ')}
                      </span>
                    )}
                  </div>
                </div>

                {/* Unread badge */}
                {chat.unreadCount > 0 && (
                  <div className="shrink-0 flex items-center justify-center w-5 h-5 rounded-full bg-green-500 text-white text-[10px] font-bold shadow-lg shadow-green-500/30">
                    {chat.unreadCount}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* New Chat Modal */}
      {showNewChatModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1e1b4b]/95 backdrop-blur-2xl rounded-[2rem] max-w-sm w-full p-6 shadow-2xl border border-white/10 text-white">
            <h3 className="font-bold text-sm text-white mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-green-400" /> Start New Test Conversation
            </h3>

            <form onSubmit={handleCreateChat} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-white/70 mb-1 font-medium">Customer Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Jordan Lee"
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  className="w-full p-3 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-white/30"
                />
              </div>

              <div>
                <label className="block text-white/70 mb-1 font-medium">Phone Number</label>
                <input
                  type="text"
                  placeholder="+1 (555) 000-0000"
                  value={newCustomerPhone}
                  onChange={(e) => setNewCustomerPhone(e.target.value)}
                  className="w-full p-3 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-white/30"
                />
              </div>

              <div>
                <label className="block text-white/70 mb-1 font-medium">
                  Attach Order (Optional)
                </label>
                <select
                  value={selectedOrderId}
                  onChange={(e) => setSelectedOrderId(e.target.value)}
                  className="w-full p-3 bg-[#0f172a] rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">No Order Attached</option>
                  {orders.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.id} — {o.customerName} ({o.status})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowNewChatModal(false)}
                  className="flex-1 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-medium border border-white/10 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/20 transition-all border border-indigo-400/30"
                >
                  Start Chat
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
