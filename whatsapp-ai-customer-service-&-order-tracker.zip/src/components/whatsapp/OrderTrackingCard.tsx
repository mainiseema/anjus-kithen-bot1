import React, { useState } from 'react';
import {
  Package,
  Truck,
  MapPin,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Phone,
  Copy,
  Check,
  FileText,
  RotateCcw,
  Navigation,
} from 'lucide-react';
import { Order } from '../../types';
import confetti from 'canvas-confetti';

interface OrderTrackingCardProps {
  order: Order;
  onActionClick?: (payload: string) => void;
}

export const OrderTrackingCard: React.FC<OrderTrackingCardProps> = ({ order, onActionClick }) => {
  const [showAllCheckpoints, setShowAllCheckpoints] = useState(false);
  const [showLiveMap, setShowLiveMap] = useState(order.status === 'out_for_delivery');
  const [copied, setCopied] = useState(false);

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'delivered':
        return {
          bg: 'bg-green-500/20 text-green-300 border-green-400/40',
          text: 'Delivered',
          icon: CheckCircle2,
        };
      case 'out_for_delivery':
        return {
          bg: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40 animate-pulse',
          text: 'Out for Delivery Today',
          icon: Truck,
        };
      case 'shipped':
        return {
          bg: 'bg-purple-500/20 text-purple-300 border-purple-400/40',
          text: 'Shipped & In Transit',
          icon: Navigation,
        };
      case 'processing':
        return {
          bg: 'bg-amber-500/20 text-amber-300 border-amber-400/40',
          text: 'Processing in Warehouse',
          icon: Clock,
        };
      case 'cancelled':
        return {
          bg: 'bg-red-500/20 text-red-300 border-red-400/40',
          text: 'Order Cancelled',
          icon: AlertCircle,
        };
      default:
        return {
          bg: 'bg-white/10 text-white/80 border-white/20',
          text: status,
          icon: Package,
        };
    }
  };

  const statusConfig = getStatusBadge(order.status);
  const StatusIcon = statusConfig.icon;

  const handleCopyTracking = () => {
    navigator.clipboard.writeText(order.courier.trackingNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTriggerConfetti = () => {
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 },
    });
  };

  return (
    <div className="bg-white/10 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-2 max-w-md w-full text-white transition-all">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-indigo-600/60 to-purple-600/60 backdrop-blur-md p-4 text-white flex items-center justify-between border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/15 rounded-xl backdrop-blur-md border border-white/20 shadow-md">
            <Package className="w-5 h-5 text-indigo-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm tracking-wide">#{order.id}</span>
              <span className="text-[11px] bg-white/20 px-2 py-0.5 rounded-full font-medium border border-white/10">
                {order.items.length} {order.items.length === 1 ? 'Item' : 'Items'}
              </span>
            </div>
            <p className="text-[11px] text-white/70 font-medium">
              ETA: {order.estimatedDelivery}
            </p>
          </div>
        </div>

        <div className="text-right">
          <div className="text-[11px] text-white/60">Total</div>
          <div className="font-bold text-sm font-mono text-white">${order.total.toFixed(2)}</div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="px-4 py-3 bg-white/5 border-b border-white/10 flex items-center justify-between">
        <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${statusConfig.bg}`}>
          <StatusIcon className="w-3.5 h-3.5" />
          <span>{statusConfig.text}</span>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-white/70">
          <Truck className="w-3.5 h-3.5 text-indigo-300" />
          <span className="font-medium text-white">{order.courier.name}</span>
        </div>
      </div>

      {/* Courier & Tracking Code */}
      <div className="px-4 py-2.5 bg-white/[0.02] flex items-center justify-between text-xs border-b border-white/10">
        <div className="flex items-center gap-2">
          <span className="text-white/50 text-[11px]">Tracking #:</span>
          <code className="bg-white/10 px-2.5 py-0.5 rounded-lg font-mono text-[11px] text-white font-semibold border border-white/10">
            {order.courier.trackingNumber}
          </code>
          <button
            onClick={handleCopyTracking}
            className="text-white/50 hover:text-white transition-colors p-1 rounded-lg hover:bg-white/10"
            title="Copy Tracking Number"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        {order.courier.trackingUrl && (
          <a
            href={order.courier.trackingUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-indigo-300 hover:text-indigo-200 hover:underline flex items-center gap-1 text-[11px] font-medium"
          >
            Carrier Site <ExternalLink className="w-3 h-3" />
          </a>
        )}
      </div>

      {/* Live Map Preview (Simulated GPS tracking) */}
      {showLiveMap && (
        <div className="relative h-44 bg-[#0a0f1d] overflow-hidden border-b border-white/10">
          <div className="absolute inset-0 bg-[#0f172a]/90">
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid-frost" width="30" height="30" patternUnits="userSpaceOnUse">
                  <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#312e81" strokeWidth="0.7" opacity="0.3" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid-frost)" />
              {/* Route line */}
              <path
                d="M 40 120 Q 120 40, 240 80 T 360 40"
                fill="none"
                stroke="#6366f1"
                strokeWidth="3.5"
                strokeDasharray="6 4"
                className="animate-pulse"
              />
            </svg>

            {/* Starting Distribution Hub Pin */}
            <div className="absolute left-8 top-28 transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
              <div className="w-6 h-6 rounded-full bg-indigo-900 border-2 border-indigo-400 flex items-center justify-center shadow-lg text-[10px] text-white">
                🏭
              </div>
              <span className="text-[9px] text-white/70 bg-black/60 px-1.5 rounded mt-0.5">Hub</span>
            </div>

            {/* Live Moving Van */}
            <div className="absolute left-[56%] top-[48%] transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-10 animate-bounce">
              <div className="w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center shadow-lg shadow-green-500/50 border-2 border-white">
                <Truck className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold text-white bg-green-700/90 px-2 py-0.5 rounded-full shadow mt-1 whitespace-nowrap border border-green-400/30">
                {order.courier.driverName ? `${order.courier.driverName} (4 stops away)` : 'Driver En Route'}
              </span>
            </div>

            {/* Destination House Pin */}
            <div className="absolute right-6 top-6 transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
              <div className="w-7 h-7 rounded-full bg-red-500 text-white flex items-center justify-center shadow-lg border-2 border-white">
                <MapPin className="w-4 h-4" />
              </div>
              <span className="text-[9px] text-white font-medium bg-red-900/90 px-1.5 py-0.5 rounded mt-0.5">
                Delivery Destination
              </span>
            </div>

            {/* Live Status Overlay */}
            <div className="absolute bottom-2 left-3 right-3 bg-white/10 backdrop-blur-md rounded-xl p-2 flex items-center justify-between border border-white/10 text-white">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-ping" />
                <span className="text-[11px] font-medium text-green-300">Live GPS Connected</span>
              </div>
              <span className="text-[11px] text-white/80">ETA: {order.courier.etaWindow || 'Today'}</span>
            </div>
          </div>
        </div>
      )}

      {/* Driver info if out for delivery */}
      {order.status === 'out_for_delivery' && order.courier.driverName && (
        <div className="p-3 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500 text-white font-bold flex items-center justify-center text-xs shadow-md">
              {order.courier.driverName.split(' ').map((n) => n[0]).join('')}
            </div>
            <div>
              <div className="text-xs font-bold text-white">{order.courier.driverName}</div>
              <div className="text-[11px] text-white/60">
                {order.courier.driverVehicle || 'Delivery Courier'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {order.courier.driverPhone && (
              <button
                onClick={() => onActionClick && onActionClick(`driver_call_${order.id}`)}
                className="p-1.5 bg-green-500 hover:bg-green-600 text-white rounded-xl transition-all flex items-center gap-1 text-xs px-3 font-medium shadow-md shadow-green-500/20"
              >
                <Phone className="w-3.5 h-3.5" /> Call
              </button>
            )}
            <button
              onClick={() => setShowLiveMap(!showLiveMap)}
              className="p-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-medium px-2.5 border border-white/10 transition-colors"
            >
              {showLiveMap ? 'Hide Map' : 'Show Map'}
            </button>
          </div>
        </div>
      )}

      {/* Checkpoints Stepper */}
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-white mb-1">
          <span className="flex items-center gap-1.5">
            <Navigation className="w-3.5 h-3.5 text-indigo-400" /> Tracking Milestones
          </span>
          <button
            onClick={() => setShowAllCheckpoints(!showAllCheckpoints)}
            className="text-[11px] text-indigo-300 font-semibold hover:underline flex items-center gap-0.5"
          >
            {showAllCheckpoints ? 'Show Less' : `All Steps (${order.checkpoints.length})`}
            {showAllCheckpoints ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>

        <div className="relative pl-5 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-white/15">
          {(showAllCheckpoints ? order.checkpoints : order.checkpoints.slice(-2)).map((cp, idx) => (
            <div key={cp.id || idx} className="relative flex items-start justify-between gap-2 text-xs">
              {/* Stepper Bullet */}
              <div
                className={`absolute -left-5 top-0.5 w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all ${
                  cp.completed
                    ? 'bg-green-500 border-[#1e1b4b] text-white shadow-sm'
                    : cp.current
                    ? 'bg-indigo-500 border-[#1e1b4b] text-white animate-pulse shadow-[0_0_12px_rgba(99,102,241,0.6)]'
                    : 'bg-white/20 border-[#1e1b4b]'
                }`}
              >
                {cp.completed && <Check className="w-2.5 h-2.5 stroke-[3]" />}
              </div>

              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span
                    className={`font-semibold ${
                      cp.current ? 'text-indigo-300' : 'text-white'
                    }`}
                  >
                    {cp.status}
                  </span>
                  {cp.current && (
                    <span className="text-[10px] px-2 py-0.2 bg-indigo-500/30 text-indigo-200 rounded-full font-semibold border border-indigo-400/30">
                      Current
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-white/60 mt-0.5">{cp.description}</p>
                <div className="flex items-center gap-2 text-[10px] text-white/40 mt-1">
                  <span className="flex items-center gap-0.5">
                    <MapPin className="w-2.5 h-2.5" /> {cp.location}
                  </span>
                  <span>•</span>
                  <span>{cp.timestamp}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Ordered Items Preview */}
      <div className="px-4 py-3 bg-white/5 border-t border-white/10 text-xs">
        <div className="text-[10px] font-semibold text-white/40 mb-2 uppercase tracking-widest">
          Package Contents
        </div>
        <div className="space-y-2.5">
          {order.items.map((item) => (
            <div key={item.id} className="flex items-center gap-3">
              <img
                src={item.image}
                alt={item.name}
                className="w-10 h-10 rounded-xl object-cover border border-white/10 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-white truncate">{item.name}</div>
                <div className="text-[11px] text-white/60 flex items-center justify-between mt-0.5">
                  <span>Qty: {item.quantity}</span>
                  <span className="font-mono font-medium text-indigo-300">
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Destination address */}
      <div className="px-4 py-2.5 bg-white/[0.02] border-t border-white/10 text-[11px] flex items-center justify-between text-white/60">
        <div className="flex items-center gap-1.5 truncate">
          <MapPin className="w-3.5 h-3.5 text-red-400 shrink-0" />
          <span className="truncate">
            Deliver to: {order.shippingAddress.street}, {order.shippingAddress.city}
          </span>
        </div>
        <span className="font-medium text-indigo-300 shrink-0">Standard</span>
      </div>

      {/* Quick Action Footer Buttons */}
      <div className="p-3 bg-white/5 border-t border-white/10 grid grid-cols-2 gap-2">
        {order.status === 'delivered' ? (
          <>
            <button
              onClick={() => {
                handleTriggerConfetti();
                if (onActionClick) onActionClick(`return ${order.id}`);
              }}
              className="py-2 px-3 bg-green-500 hover:bg-green-600 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-green-500/20 border border-green-400/30"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Return / Exchange
            </button>
            <button
              onClick={() => onActionClick && onActionClick(`invoice_${order.id}`)}
              className="py-2 px-3 bg-white/10 hover:bg-white/20 text-white border border-white/10 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors backdrop-blur-md"
            >
              <FileText className="w-3.5 h-3.5" /> Invoice PDF
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => onActionClick && onActionClick(`change address for ${order.id}`)}
              className="py-2 px-3 bg-white/10 hover:bg-white/20 text-white border border-white/10 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors backdrop-blur-md"
            >
              <MapPin className="w-3.5 h-3.5 text-indigo-400" /> Change Address
            </button>
            <button
              onClick={() => onActionClick && onActionClick('agent')}
              className="py-2 px-3 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-indigo-500/20 border border-indigo-400/30"
            >
              <Phone className="w-3.5 h-3.5" /> Live Agent Help
            </button>
          </>
        )}
      </div>
    </div>
  );
};
