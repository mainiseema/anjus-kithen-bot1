import React, { useState } from 'react';
import { X, Bot, Save } from 'lucide-react';
import { BotAutomationSettings } from '../../types';

interface BotSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: BotAutomationSettings;
  onSave: (newSettings: BotAutomationSettings) => void;
}

export const BotSettingsModal: React.FC<BotSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
}) => {
  const [form, setForm] = useState<BotAutomationSettings>({ ...settings });
  const [keywordInput, setKeywordInput] = useState('');

  if (!isOpen) return null;

  const handleAddKeyword = () => {
    if (!keywordInput.trim()) return;
    if (!form.autoHandoffKeywords.includes(keywordInput.trim())) {
      setForm({
        ...form,
        autoHandoffKeywords: [...form.autoHandoffKeywords, keywordInput.trim()],
      });
    }
    setKeywordInput('');
  };

  const handleRemoveKeyword = (kw: string) => {
    setForm({
      ...form,
      autoHandoffKeywords: form.autoHandoffKeywords.filter((k) => k !== kw),
    });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(form);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#1e1b4b]/95 backdrop-blur-2xl rounded-[2rem] max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-white/15 animate-in zoom-in-95 duration-150 text-white">
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/10 text-green-400 rounded-2xl border border-white/10 shadow-md">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">
                WhatsApp Bot & AI Rules
              </h2>
              <p className="text-xs text-white/50">
                Configure tone, automated responses, and human handoff triggers.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/60 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-5 space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-white/70 mb-1">
                Assistant Name
              </label>
              <input
                type="text"
                value={form.botName}
                onChange={(e) => setForm({ ...form, botName: e.target.value })}
                className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block font-medium text-white/70 mb-1">
                Tone of Voice
              </label>
              <select
                value={form.tone}
                onChange={(e) => setForm({ ...form, tone: e.target.value as any })}
                className="w-full p-2.5 bg-[#0f172a] rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="friendly">Friendly & Helpful (Recommended)</option>
                <option value="professional">Professional & Formal</option>
                <option value="concise">Concise & Direct</option>
                <option value="playful">Playful & Emoji-Rich</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-medium text-white/70 mb-1">
              Welcome Greeting (WhatsApp Markdown)
            </label>
            <textarea
              rows={3}
              value={form.welcomeMessage}
              onChange={(e) => setForm({ ...form, welcomeMessage: e.target.value })}
              className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-xs leading-relaxed"
            />
          </div>

          <div>
            <label className="block font-medium text-white/70 mb-1">
              Out of Hours Message (8 PM - 8 AM)
            </label>
            <textarea
              rows={2}
              value={form.outOfHoursMessage}
              onChange={(e) => setForm({ ...form, outOfHoursMessage: e.target.value })}
              className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs leading-relaxed"
            />
          </div>

          <div>
            <label className="block font-medium text-white/70 mb-1">
              Auto Human Agent Escalation Keywords
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                placeholder="Add trigger word (e.g. manager, agent)..."
                value={keywordInput}
                onChange={(e) => setKeywordInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddKeyword();
                  }
                }}
                className="flex-1 p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="button"
                onClick={handleAddKeyword}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold border border-white/10 transition-colors"
              >
                Add
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-2.5 bg-white/5 rounded-xl border border-white/10">
              {form.autoHandoffKeywords.map((kw) => (
                <span
                  key={kw}
                  className="px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-400/30 rounded-full text-[11px] font-medium flex items-center gap-1.5"
                >
                  {kw}
                  <button
                    type="button"
                    onClick={() => handleRemoveKeyword(kw)}
                    className="hover:text-red-400 text-amber-300/70"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>

          <div className="pt-3 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold border border-white/10 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-500/25 border border-indigo-400/30 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Save Bot Rules</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
