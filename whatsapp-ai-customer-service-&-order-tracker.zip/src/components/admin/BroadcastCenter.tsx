import React, { useState } from 'react';
import {
  Send,
  Radio,
  FileCode,
  CheckCircle2,
} from 'lucide-react';
import { DEFAULT_TEMPLATES, INITIAL_CUSTOMER_CHATS } from '../../data/mockData';
import { WhatsAppTemplate } from '../../types';
import confetti from 'canvas-confetti';

interface BroadcastCenterProps {
  onSendBroadcast: (template: WhatsAppTemplate, targetPhone: string, variables: string[]) => void;
}

export const BroadcastCenter: React.FC<BroadcastCenterProps> = ({ onSendBroadcast }) => {
  const [selectedTemplate, setSelectedTemplate] = useState<WhatsAppTemplate>(DEFAULT_TEMPLATES[0]);
  const [targetPhone, setTargetPhone] = useState(INITIAL_CUSTOMER_CHATS[0].phone);
  const [var1, setVar1] = useState('Alex Johnson');
  const [var2, setVar2] = useState('ORD-9821');
  const [var3, setVar3] = useState('FedEx Express');
  const [var4, setVar4] = useState('FDX-9982-1402-99');
  const [var5, setVar5] = useState('Today by 4:30 PM');
  const [broadcastSent, setBroadcastSent] = useState(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    onSendBroadcast(selectedTemplate, targetPhone, [var1, var2, var3, var4, var5]);
    confetti({ particleCount: 35, spread: 50 });
    setBroadcastSent(true);
    setTimeout(() => setBroadcastSent(false), 3000);
  };

  const renderPreviewBody = () => {
    let text = selectedTemplate.body;
    text = text.replace('{{1}}', var1 || 'Alex');
    text = text.replace('{{2}}', var2 || 'ORD-9821');
    text = text.replace('{{3}}', var3 || 'Courier');
    text = text.replace('{{4}}', var4 || 'TRK-1234');
    text = text.replace('{{5}}', var5 || 'Today');
    return text;
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto space-y-6 text-white">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2.5">
          <h1 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <Radio className="w-5 h-5 text-indigo-400" /> WhatsApp Template Broadcaster
          </h1>
          <span className="text-[10px] bg-green-500/20 text-green-300 border border-green-400/30 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider backdrop-blur-md">
            Meta Cloud API Ready
          </span>
        </div>
        <p className="text-xs text-white/50 mt-1">
          Dispatch automated utility notifications (Order Dispatch, Driver Out for Delivery, Delivery Confirmations).
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Template Selector & Params */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white/5 backdrop-blur-2xl p-6 rounded-2xl border border-white/10 shadow-xl space-y-4">
            <h3 className="font-bold text-sm text-white">
              1. Choose Pre-Approved WhatsApp Template
            </h3>

            <div className="grid grid-cols-1 gap-2.5">
              {DEFAULT_TEMPLATES.map((tpl) => (
                <div
                  key={tpl.id}
                  onClick={() => setSelectedTemplate(tpl)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    selectedTemplate.id === tpl.id
                      ? 'border-indigo-400/60 bg-indigo-500/15 ring-1 ring-indigo-400/40 shadow-lg shadow-indigo-500/10'
                      : 'border-white/10 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-white flex items-center gap-1.5">
                      <FileCode className="w-3.5 h-3.5 text-indigo-400" />
                      {tpl.name}
                    </span>
                    <span className="text-[10px] bg-white/10 border border-white/10 text-white/60 px-2 py-0.5 rounded-lg font-mono">
                      {tpl.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-white/60 mt-1.5 line-clamp-2">
                    {tpl.body}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Form & Dynamic Variables */}
          <form
            onSubmit={handleSend}
            className="bg-white/5 backdrop-blur-2xl p-6 rounded-2xl border border-white/10 shadow-xl space-y-4"
          >
            <h3 className="font-bold text-sm text-white">
              2. Target Recipient & Variables
            </h3>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-white/70 font-medium mb-1">
                  Recipient WhatsApp Number / Customer
                </label>
                <select
                  value={targetPhone}
                  onChange={(e) => {
                    setTargetPhone(e.target.value);
                    const matchedChat = INITIAL_CUSTOMER_CHATS.find((c) => c.phone === e.target.value);
                    if (matchedChat) setVar1(matchedChat.name);
                  }}
                  className="w-full p-3 bg-[#0f172a] rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {INITIAL_CUSTOMER_CHATS.map((c) => (
                    <option key={c.id} value={c.phone}>
                      {c.name} ({c.phone}) {c.linkedOrderId ? `— Order #${c.linkedOrderId}` : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">
                    Variable &#123;&#123;1&#125;&#125; (Customer Name)
                  </label>
                  <input
                    type="text"
                    value={var1}
                    onChange={(e) => setVar1(e.target.value)}
                    className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-white/70 font-medium mb-1">
                    Variable &#123;&#123;2&#125;&#125; (Order ID)
                  </label>
                  <input
                    type="text"
                    value={var2}
                    onChange={(e) => setVar2(e.target.value)}
                    className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-white/70 font-medium mb-1">
                    &#123;&#123;3&#125;&#125; (Courier)
                  </label>
                  <input
                    type="text"
                    value={var3}
                    onChange={(e) => setVar3(e.target.value)}
                    className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-white/70 font-medium mb-1">
                    &#123;&#123;4&#125;&#125; (Tracking #)
                  </label>
                  <input
                    type="text"
                    value={var4}
                    onChange={(e) => setVar4(e.target.value)}
                    className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-white/70 font-medium mb-1">
                    &#123;&#123;5&#125;&#125; (ETA Window)
                  </label>
                  <input
                    type="text"
                    value={var5}
                    onChange={(e) => setVar5(e.target.value)}
                    className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/25 transition-all border border-indigo-400/30"
            >
              <Send className="w-4 h-4" />
              <span>Send WhatsApp Notification Now</span>
            </button>

            {broadcastSent && (
              <div className="p-3 bg-green-500/20 text-green-300 border border-green-400/30 rounded-xl text-xs flex items-center gap-2 font-medium animate-in fade-in backdrop-blur-md">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                <span>Message dispatched successfully to {targetPhone}! Check the WhatsApp chat simulator.</span>
              </div>
            )}
          </form>
        </div>

        {/* Right: Live WhatsApp Phone Message Preview */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="w-full max-w-sm bg-white/5 backdrop-blur-2xl rounded-[2.5rem] border border-white/15 shadow-2xl overflow-hidden p-5 space-y-4">
            <div className="text-center pb-2 border-b border-white/10">
              <span className="text-[10px] font-bold text-white/50 uppercase tracking-widest">
                WhatsApp Live Preview
              </span>
            </div>

            {/* Rendered WhatsApp Bubble */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl rounded-tl-xs p-4 shadow-xl text-xs space-y-2.5 border border-white/10 text-white">
              {selectedTemplate.header && (
                <div className="font-bold text-white text-xs border-b border-white/10 pb-2">
                  {selectedTemplate.header}
                </div>
              )}

              <p className="text-white/90 leading-relaxed text-xs">
                {renderPreviewBody()}
              </p>

              {selectedTemplate.footer && (
                <div className="text-[10px] text-white/40 pt-1">
                  {selectedTemplate.footer}
                </div>
              )}

              {/* Template Buttons */}
              {selectedTemplate.buttons && (
                <div className="space-y-1.5 pt-2.5 border-t border-white/10">
                  {selectedTemplate.buttons.map((b, i) => (
                    <div
                      key={i}
                      className="py-1.5 px-3 text-center text-xs font-semibold text-indigo-300 bg-white/5 rounded-xl border border-white/10"
                    >
                      {b.text}
                    </div>
                  ))}
                </div>
              )}

              <div className="text-[10px] text-right text-white/40">Just now</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
