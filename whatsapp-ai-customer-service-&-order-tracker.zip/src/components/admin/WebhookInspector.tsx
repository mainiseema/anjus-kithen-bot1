import React, { useState } from 'react';
import {
  Code2,
  QrCode,
  Copy,
  Check,
} from 'lucide-react';
import { DEFAULT_BOT_SETTINGS } from '../../data/mockData';

export const WebhookInspector: React.FC = () => {
  const [selectedPayloadTab, setSelectedPayloadTab] = useState<'incoming_msg' | 'interactive_btn' | 'delivery_status' | 'graph_api_send'>('incoming_msg');
  const [copied, setCopied] = useState(false);
  const [waMeText, setWaMeText] = useState('Hi! Track order ORD-9821');

  const cleanPhone = DEFAULT_BOT_SETTINGS.businessPhone.replace(/\D/g, '');
  const waMeLink = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(waMeText)}`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const payloads = {
    incoming_msg: {
      object: 'whatsapp_business_account',
      entry: [
        {
          id: 'WHATSAPP_BUSINESS_ACCOUNT_ID',
          changes: [
            {
              value: {
                messaging_product: 'whatsapp',
                metadata: {
                  display_phone_number: '+1 800 555 0199',
                  phone_number_id: '109823489123049',
                },
                contacts: [
                  {
                    profile: { name: 'Alex Johnson' },
                    wa_id: '15552345678',
                  },
                ],
                messages: [
                  {
                    from: '15552345678',
                    id: 'wamid.HBgLMTU1NTIzNDU2NzgVAgASGBQzQT...',
                    timestamp: '1724486400',
                    text: {
                      body: 'Where is my order ORD-9821?',
                    },
                    type: 'text',
                  },
                ],
              },
              field: 'messages',
            },
          ],
        },
      ],
    },
    interactive_btn: {
      object: 'whatsapp_business_account',
      entry: [
        {
          changes: [
            {
              value: {
                messages: [
                  {
                    from: '15552345678',
                    id: 'wamid.HBgLMTU1NTIzNDU2NzgVAgASGBQ...',
                    timestamp: '1724486415',
                    type: 'interactive',
                    interactive: {
                      type: 'button_reply',
                      button_reply: {
                        id: 'btn-driver',
                        title: '📞 Contact Courier Driver',
                      },
                    },
                  },
                ],
              },
              field: 'messages',
            },
          ],
        },
      ],
    },
    delivery_status: {
      object: 'whatsapp_business_account',
      entry: [
        {
          changes: [
            {
              value: {
                statuses: [
                  {
                    id: 'wamid.HBgLMTU1NTIzNDU2NzgVAgASGBQzQT...',
                    status: 'read',
                    timestamp: '1724486420',
                    recipient_id: '15552345678',
                  },
                ],
              },
              field: 'messages',
            },
          ],
        },
      ],
    },
    graph_api_send: {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: '15552345678',
      type: 'interactive',
      interactive: {
        type: 'button',
        header: {
          type: 'text',
          text: '📦 Live Order Tracking: #ORD-9821',
        },
        body: {
          text: 'Status: Out for Delivery Today!\nCourier: FedEx Express Direct\nDriver ETA: 2:30 PM – 4:30 PM',
        },
        footer: {
          text: 'ZapFlow Customer Logistics',
        },
        action: {
          buttons: [
            {
              type: 'reply',
              reply: { id: 'btn-driver', title: '📞 Contact Driver' },
            },
            {
              type: 'reply',
              reply: { id: 'btn-gate', title: '🚪 Leave at Door' },
            },
          ],
        },
      },
    },
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto space-y-6 text-white">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2.5">
          <h1 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
            <Code2 className="w-5 h-5 text-indigo-400" /> WhatsApp Cloud API & Webhook Inspector
          </h1>
          <span className="text-[10px] bg-green-500/20 text-green-300 border border-green-400/30 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider backdrop-blur-md">
            Meta Graph API v19.0
          </span>
        </div>
        <p className="text-xs text-white/50 mt-1">
          Inspect official Meta WhatsApp Cloud API JSON payloads for direct enterprise backend integration.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: JSON Payloads Inspector */}
        <div className="lg:col-span-7 bg-white/5 backdrop-blur-2xl rounded-2xl border border-white/10 shadow-xl overflow-hidden flex flex-col">
          {/* Tabs */}
          <div className="flex items-center justify-between p-3.5 bg-white/5 border-b border-white/10">
            <div className="flex items-center gap-1.5 text-xs overflow-x-auto no-scrollbar">
              {[
                { id: 'incoming_msg', label: 'Incoming Message' },
                { id: 'interactive_btn', label: 'Interactive Click' },
                { id: 'delivery_status', label: 'Read Receipt (✓✓)' },
                { id: 'graph_api_send', label: 'Outgoing Bot Payload' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedPayloadTab(tab.id as any)}
                  className={`px-3 py-1.5 rounded-xl font-mono text-[11px] transition-all whitespace-nowrap ${
                    selectedPayloadTab === tab.id
                      ? 'bg-indigo-500 text-white font-bold shadow-lg shadow-indigo-500/20 border border-indigo-400/30'
                      : 'text-white/60 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => handleCopy(JSON.stringify(payloads[selectedPayloadTab], null, 2))}
              className="p-1.5 text-white/60 hover:text-white rounded-lg flex items-center gap-1 text-xs font-mono transition-colors"
              title="Copy JSON Payload"
            >
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* JSON code viewer */}
          <div className="p-5 flex-1 overflow-x-auto font-mono text-xs text-indigo-200 leading-relaxed max-h-[480px]">
            <pre>{JSON.stringify(payloads[selectedPayloadTab], null, 2)}</pre>
          </div>
        </div>

        {/* Right: Click to Chat QR Code Generator */}
        <div className="lg:col-span-5 bg-white/5 backdrop-blur-2xl p-6 rounded-2xl border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <QrCode className="w-4 h-4 text-indigo-400" /> "Click to Chat" wa.me Generator
            </h3>
            <span className="text-[10px] text-white/40">Mobile Deep-Link</span>
          </div>

          <div className="text-xs text-white/70">
            Generate customized WhatsApp direct links (`https://wa.me/...`) for website widgets, customer receipts, and shipping emails.
          </div>

          <div className="space-y-2 text-xs">
            <label className="block text-white/70 font-medium">
              Pre-filled Message Prompt
            </label>
            <input
              type="text"
              value={waMeText}
              onChange={(e) => setWaMeText(e.target.value)}
              className="w-full p-2.5 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Direct Link Preview */}
          <div className="p-3.5 bg-white/5 backdrop-blur-md rounded-xl border border-white/10 space-y-2">
            <span className="text-[11px] font-bold text-white/50">Live wa.me URL:</span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={waMeLink}
                className="w-full bg-white/5 p-2 rounded-lg border border-white/10 text-[11px] font-mono text-indigo-300 select-all"
              />
              <button
                onClick={() => handleCopy(waMeLink)}
                className="p-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-colors shadow-md"
                title="Copy Link"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Stylized QR Code Box */}
          <div className="p-6 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl flex flex-col items-center justify-center space-y-3 text-center">
            {/* SVG Simulated QR Code */}
            <div className="p-3 bg-white rounded-2xl shadow-xl">
              <svg width="120" height="120" viewBox="0 0 120 120" fill="none">
                <rect width="120" height="120" fill="white" />
                <rect x="10" y="10" width="30" height="30" fill="#0f172a" />
                <rect x="15" y="15" width="20" height="20" fill="white" />
                <rect x="20" y="20" width="10" height="10" fill="#0f172a" />

                <rect x="80" y="10" width="30" height="30" fill="#0f172a" />
                <rect x="85" y="15" width="20" height="20" fill="white" />
                <rect x="90" y="20" width="10" height="10" fill="#0f172a" />

                <rect x="10" y="80" width="30" height="30" fill="#0f172a" />
                <rect x="15" y="85" width="20" height="20" fill="white" />
                <rect x="20" y="90" width="10" height="10" fill="#0f172a" />

                {/* Data Grid */}
                <rect x="50" y="20" width="10" height="10" fill="#0f172a" />
                <rect x="65" y="35" width="10" height="10" fill="#0f172a" />
                <rect x="50" y="50" width="20" height="20" fill="#6366f1" />
                <rect x="80" y="60" width="10" height="10" fill="#0f172a" />
                <rect x="20" y="55" width="10" height="10" fill="#0f172a" />
                <rect x="60" y="85" width="15" height="15" fill="#0f172a" />
                <rect x="90" y="90" width="15" height="15" fill="#0f172a" />
              </svg>
            </div>
            <p className="text-xs text-white/70 font-medium">
              Scan with WhatsApp Camera to launch live test
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
