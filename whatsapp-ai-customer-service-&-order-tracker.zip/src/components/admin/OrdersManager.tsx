import React, { useState } from 'react';
import {
  Package,
  Search,
  Filter,
  Plus,
  Truck,
  CheckCircle2,
  Clock,
  AlertCircle,
  Eye,
  Send,
  MapPin,
  User,
  Phone,
  Mail,
  ChevronRight,
  Sparkles,
  X,
} from 'lucide-react';
import { Order, OrderStatus } from '../../types';
import confetti from 'canvas-confetti';

interface OrdersManagerProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, note?: string) => void;
  onSendProactiveNotification: (order: Order, type: 'shipped' | 'out_for_delivery' | 'delivered') => void;
  onAddNewOrder: (order: Order) => void;
  onOpenChatWithOrder?: (orderId: string) => void;
}

export const OrdersManager: React.FC<OrdersManagerProps> = ({
  orders,
  onUpdateOrderStatus,
  onSendProactiveNotification,
  onAddNewOrder,
  onOpenChatWithOrder,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // New Order Form State
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [newCustomerEmail, setNewCustomerEmail] = useState('');
  const [newStreet, setNewStreet] = useState('');
  const [newCity, setNewCity] = useState('');
  const [newState, setNewState] = useState('');
  const [newZip, setNewZip] = useState('');
  const [newItemName, setNewItemName] = useState('Premium Active ANC Headphones');
  const [newItemPrice, setNewItemPrice] = useState('199.99');
  const [newCourier, setNewCourier] = useState('FedEx Express');

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerPhone.includes(searchQuery) ||
      o.courier.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (statusFilter !== 'all' && o.status !== statusFilter) return false;
    return true;
  });

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'delivered':
        return 'bg-green-500/20 text-green-300 border-green-400/40';
      case 'out_for_delivery':
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40 animate-pulse';
      case 'shipped':
        return 'bg-purple-500/20 text-purple-300 border-purple-400/40';
      case 'processing':
        return 'bg-amber-500/20 text-amber-300 border-amber-400/40';
      case 'cancelled':
        return 'bg-red-500/20 text-red-300 border-red-400/40';
      default:
        return 'bg-white/10 text-white/80 border-white/20';
    }
  };

  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    onUpdateOrderStatus(orderId, newStatus);
    if (newStatus === 'delivered') {
      confetti({ particleCount: 40, spread: 50, origin: { y: 0.7 } });
    }
    if (selectedOrder && selectedOrder.id === orderId) {
      setSelectedOrder({
        ...selectedOrder,
        status: newStatus,
      });
    }
  };

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    const priceNum = parseFloat(newItemPrice) || 99.99;

    const order: Order = {
      id: newId,
      customerName: newCustomerName || 'Test Customer',
      customerPhone: newCustomerPhone || '+1 (555) 302-9911',
      customerEmail: newCustomerEmail || 'customer@example.com',
      items: [
        {
          id: `item-${Date.now()}`,
          name: newItemName,
          quantity: 1,
          price: priceNum,
          sku: 'SKU-TEST-01',
          image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format&fit=crop&q=80',
        },
      ],
      subtotal: priceNum,
      shippingCost: 0,
      discount: 0,
      total: priceNum,
      status: 'processing',
      createdAt: new Date().toISOString(),
      estimatedDelivery: '3 business days',
      shippingAddress: {
        street: newStreet || '123 Market St',
        city: newCity || 'San Francisco',
        state: newState || 'CA',
        postalCode: newZip || '94105',
        country: 'United States',
      },
      courier: {
        name: newCourier,
        trackingNumber: `${newCourier.substring(0, 3).toUpperCase()}-${Math.floor(100000000 + Math.random() * 900000000)}`,
        trackingUrl: 'https://fedex.com/track',
      },
      checkpoints: [
        {
          id: `chk-1`,
          status: 'Order Placed',
          description: 'Payment authorized and verified',
          location: 'Fulfillment Center',
          timestamp: 'Just now',
          completed: true,
          current: true,
        },
      ],
      paymentMethod: 'Credit Card (•••• 4242)',
      paymentStatus: 'paid',
      canCancel: true,
      canReturn: true,
    };

    onAddNewOrder(order);
    setShowAddModal(false);
    setNewCustomerName('');
    setNewCustomerPhone('');
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto text-white">
      {/* Top Header */}
      <div className="p-4 sm:p-6 bg-white/[0.03] border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              Orders & Fulfillment Hub
            </h1>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 bg-green-500/20 text-green-300 border border-green-400/30 rounded-full">
              {orders.length} Active Records
            </span>
          </div>
          <p className="text-xs text-white/50 mt-1">
            Real-time fulfillment tracking integrated with automated WhatsApp customer notification triggers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl text-xs font-medium flex items-center gap-1.5 shadow-lg shadow-indigo-500/20 transition-all border border-indigo-400/30"
          >
            <Plus className="w-4 h-4" />
            <span>Create Mock Order</span>
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-4 sm:px-6 bg-white/[0.02] border-b border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search Order ID, customer, tracking #..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 text-xs text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-white/30 backdrop-blur-md transition-all"
          />
        </div>

        <div className="flex items-center gap-1.5 text-xs overflow-x-auto w-full sm:w-auto no-scrollbar">
          {[
            { id: 'all', label: 'All Orders' },
            { id: 'out_for_delivery', label: 'Out for Delivery' },
            { id: 'shipped', label: 'In Transit' },
            { id: 'processing', label: 'Processing' },
            { id: 'delivered', label: 'Delivered' },
            { id: 'cancelled', label: 'Cancelled' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3 py-1.5 rounded-xl font-medium transition-all shrink-0 ${
                statusFilter === tab.id
                  ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/20 border border-indigo-400/30'
                  : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Orders Table */}
      <div className="p-4 sm:p-6 flex-1">
        <div className="bg-white/5 backdrop-blur-2xl rounded-2xl border border-white/10 shadow-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/5 text-white/50 font-semibold border-b border-white/10 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3.5 px-4">Order ID & Date</th>
                  <th className="py-3.5 px-4">Customer</th>
                  <th className="py-3.5 px-4">Items Summary</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Courier / Tracking</th>
                  <th className="py-3.5 px-4">Total</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-white/40">
                      <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
                      No orders found matching criteria
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => (
                    <tr
                      key={order.id}
                      className="hover:bg-white/5 transition-colors"
                    >
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <Package className="w-3.5 h-3.5 text-indigo-400" />
                          <span>#{order.id}</span>
                        </div>
                        <div className="text-[11px] text-white/40 mt-0.5">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-white">
                          {order.customerName}
                        </div>
                        <div className="text-[11px] text-white/50 font-mono">
                          {order.customerPhone}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="truncate font-medium text-white/90">
                          {order.items.map((i) => `${i.name} (x${i.quantity})`).join(', ')}
                        </div>
                        <div className="text-[11px] text-white/40">
                          To: {order.shippingAddress.city}, {order.shippingAddress.state}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold border capitalize ${getStatusBadge(
                            order.status
                          )}`}
                        >
                          {order.status.replace(/_/g, ' ')}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-medium text-white">
                          {order.courier.name}
                        </div>
                        <div className="font-mono text-[10px] text-white/50">
                          {order.courier.trackingNumber}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-mono font-bold text-white">
                        ${order.total.toFixed(2)}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setSelectedOrder(order)}
                            className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all border border-white/10 backdrop-blur-md"
                            title="View / Manage Order"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {onOpenChatWithOrder && (
                            <button
                              onClick={() => onOpenChatWithOrder(order.id)}
                              className="px-3 py-1.5 bg-green-500/20 hover:bg-green-500/30 text-green-300 border border-green-400/30 rounded-xl font-medium text-[11px] flex items-center gap-1 transition-all backdrop-blur-md"
                              title="Test In WhatsApp Simulator"
                            >
                              <span>WhatsApp</span>
                              <ChevronRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Order Detail & Status Changer Drawer */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex justify-end">
          <div className="bg-[#1e1b4b]/95 backdrop-blur-2xl w-full max-w-lg h-full p-6 shadow-2xl overflow-y-auto space-y-6 animate-in slide-in-from-right duration-200 border-l border-white/15 text-white">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest">
                  Order Management
                </span>
                <h2 className="text-xl font-black text-white">
                  #{selectedOrder.id}
                </h2>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-xl border border-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Status Updater */}
            <div className="p-4 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-green-400" /> Real-Time Status Updater
                </span>
                <span className="text-[11px] text-green-400">
                  Auto-dispatches WhatsApp Alert
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                {(['processing', 'shipped', 'out_for_delivery', 'delivered'] as OrderStatus[]).map(
                  (st) => (
                    <button
                      key={st}
                      onClick={() => handleStatusChange(selectedOrder.id, st)}
                      className={`p-2.5 rounded-xl font-medium capitalize transition-all text-center ${
                        selectedOrder.status === st
                          ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/30'
                          : 'bg-white/10 text-white/70 border border-white/10 hover:bg-white/20'
                      }`}
                    >
                      Mark as {st.replace(/_/g, ' ')}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Proactive Notification Triggers */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-white/70">
                Trigger WhatsApp Push Notification to Customer:
              </span>
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => {
                    onSendProactiveNotification(selectedOrder, 'out_for_delivery');
                  }}
                  className="p-3 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded-xl text-xs font-medium flex items-center justify-between border border-indigo-400/30 transition-all backdrop-blur-md"
                >
                  <span className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-indigo-300" /> Send "Out for Delivery" Alert
                  </span>
                  <Send className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    onSendProactiveNotification(selectedOrder, 'delivered');
                  }}
                  className="p-3 bg-green-500/20 hover:bg-green-500/30 text-green-300 rounded-xl text-xs font-medium flex items-center justify-between border border-green-400/30 transition-all backdrop-blur-md"
                >
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-300" /> Send "Delivery Completed" Alert
                  </span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Customer Details */}
            <div className="p-4 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 space-y-2 text-xs">
              <h4 className="font-bold text-white">Customer & Shipping</h4>
              <div className="text-white/70 space-y-1.5">
                <div className="flex items-center gap-2">
                  <User className="w-3.5 h-3.5 text-white/40" />
                  <span>{selectedOrder.customerName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-white/40" />
                  <span>{selectedOrder.customerPhone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-white/40" />
                  <span>{selectedOrder.customerEmail}</span>
                </div>
                <div className="flex items-start gap-2 pt-1">
                  <MapPin className="w-3.5 h-3.5 text-red-400 mt-0.5 shrink-0" />
                  <span>
                    {selectedOrder.shippingAddress.street}, {selectedOrder.shippingAddress.city},{' '}
                    {selectedOrder.shippingAddress.state} {selectedOrder.shippingAddress.postalCode}
                  </span>
                </div>
              </div>
            </div>

            {/* Items List */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
                Order Items ({selectedOrder.items.length})
              </h4>
              {selectedOrder.items.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 bg-white/5 backdrop-blur-md rounded-2xl flex items-center gap-3 border border-white/10"
                >
                  <img src={item.image} alt={item.name} className="w-12 h-12 rounded-xl object-cover" />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-xs text-white truncate">
                      {item.name}
                    </div>
                    <div className="text-[11px] text-white/50">Qty: {item.quantity}</div>
                  </div>
                  <div className="font-mono font-bold text-xs text-indigo-300">
                    ${(item.price * item.quantity).toFixed(2)}
                  </div>
                </div>
              ))}
            </div>

            {/* Close */}
            <button
              onClick={() => setSelectedOrder(null)}
              className="w-full py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold border border-white/10 transition-colors backdrop-blur-md"
            >
              Close Drawer
            </button>
          </div>
        </div>
      )}

      {/* Add New Mock Order Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1e1b4b]/95 backdrop-blur-2xl rounded-[2rem] max-w-md w-full p-6 shadow-2xl border border-white/15 text-white">
            <h3 className="font-bold text-base text-white mb-4 flex items-center gap-2">
              <Package className="w-5 h-5 text-green-400" /> Create New Test Order
            </h3>

            <form onSubmit={handleCreateOrder} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-white/70 mb-1 font-medium">Customer Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Jennifer Taylor"
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  className="w-full p-3 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-white/30"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-white/70 mb-1 font-medium">Phone</label>
                  <input
                    type="text"
                    placeholder="+1 (555) 302-9911"
                    value={newCustomerPhone}
                    onChange={(e) => setNewCustomerPhone(e.target.value)}
                    className="w-full p-3 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-white/30"
                  />
                </div>
                <div>
                  <label className="block text-white/70 mb-1 font-medium">Email</label>
                  <input
                    type="email"
                    placeholder="jennifer@example.com"
                    value={newCustomerEmail}
                    onChange={(e) => setNewCustomerEmail(e.target.value)}
                    className="w-full p-3 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-white/30"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/70 mb-1 font-medium">Product Name</label>
                <input
                  type="text"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  className="w-full p-3 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-white/30"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-white/70 mb-1 font-medium">Price ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newItemPrice}
                    onChange={(e) => setNewItemPrice(e.target.value)}
                    className="w-full p-3 bg-white/5 rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-white/30"
                  />
                </div>
                <div>
                  <label className="block text-white/70 mb-1 font-medium">Courier</label>
                  <select
                    value={newCourier}
                    onChange={(e) => setNewCourier(e.target.value)}
                    className="w-full p-3 bg-[#0f172a] rounded-xl border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="FedEx Express">FedEx Express</option>
                    <option value="DHL Express">DHL Express</option>
                    <option value="UPS Ground">UPS Ground</option>
                    <option value="USPS Priority">USPS Priority</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-medium border border-white/10 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/25 transition-all border border-indigo-400/30"
                >
                  Create Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
