import React from 'react';
import {
  TrendingUp,
  MessageSquare,
  Clock,
  Star,
  Activity,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { DEFAULT_ANALYTICS } from '../../data/mockData';

export const AnalyticsDashboard: React.FC = () => {
  const analytics = DEFAULT_ANALYTICS;

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto space-y-6 text-white">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2.5">
            <Activity className="w-5 h-5 text-indigo-400" />
            WhatsApp AI Performance & Analytics
          </h1>
          <p className="text-xs text-white/50 mt-1">
            Real-time tracking of automated conversations, customer satisfaction, and containment rates.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 px-3 py-1 bg-green-500/20 text-green-300 text-xs font-bold rounded-full border border-green-400/30 backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-ping" />
            Live AI Telemetry
          </span>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white/5 backdrop-blur-2xl p-5 rounded-2xl border border-white/10 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-white/50 uppercase tracking-widest">Total Inquiries</span>
            <div className="p-2 bg-white/10 rounded-xl text-green-400 border border-white/10 shadow-md">
              <MessageSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-3 font-mono">
            {analytics.totalInquiries.toLocaleString()}
          </div>
          <div className="flex items-center gap-1 text-[11px] text-green-400 font-semibold mt-1">
            <TrendingUp className="w-3 h-3" />
            <span>+18.4% this week</span>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-2xl p-5 rounded-2xl border border-white/10 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-white/50 uppercase tracking-widest">Resolution Rate</span>
            <div className="p-2 bg-white/10 rounded-xl text-indigo-300 border border-white/10 shadow-md">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-3 font-mono">
            {((analytics.resolvedByBot / analytics.totalInquiries) * 100).toFixed(1)}%
          </div>
          <div className="text-[11px] text-white/50 mt-1">
            {analytics.resolvedByBot} resolved without agent
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-2xl p-5 rounded-2xl border border-white/10 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-white/50 uppercase tracking-widest">Avg Response Time</span>
            <div className="p-2 bg-white/10 rounded-xl text-purple-300 border border-white/10 shadow-md">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-3 font-mono">
            {(analytics.avgResponseTimeMs / 1000).toFixed(2)}s
          </div>
          <div className="text-[11px] text-green-400 font-semibold mt-1">
            Instant 24/7 Automation
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-2xl p-5 rounded-2xl border border-white/10 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-white/50 uppercase tracking-widest">CSAT Score</span>
            <div className="p-2 bg-white/10 rounded-xl text-amber-400 border border-white/10 shadow-md">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-3 font-mono flex items-baseline gap-1">
            <span>{analytics.csatRating}</span>
            <span className="text-xs font-normal text-white/40">/ 5.0</span>
          </div>
          <div className="text-[11px] text-white/50 mt-1">
            96% 5-star positive feedback
          </div>
        </div>
      </div>

      {/* Main Charts & Breakdown Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Inquiries by Category */}
        <div className="lg:col-span-2 bg-white/5 backdrop-blur-2xl p-6 rounded-2xl border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white">
              Customer Inquiry Distribution
            </h3>
            <span className="text-xs text-white/40">Last 30 Days</span>
          </div>

          <div className="space-y-4">
            {analytics.inquiriesByCategory.map((cat, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-white/90">{cat.category}</span>
                  <span className="font-mono text-white/50">
                    {cat.count} ({cat.percentage}%)
                  </span>
                </div>
                <div className="h-2.5 w-full bg-white/10 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      i === 0
                        ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]'
                        : i === 1
                        ? 'bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.6)]'
                        : i === 2
                        ? 'bg-purple-500 shadow-[0_0_8px_rgba(168,85,247,0.6)]'
                        : i === 3
                        ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.6)]'
                        : 'bg-teal-500'
                    }`}
                    style={{ width: `${cat.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Containment Rate Explanation */}
          <div className="mt-5 p-4 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-green-400 shrink-0 mt-0.5" />
            <div className="text-xs text-white/80 leading-relaxed">
              <span className="font-bold text-white">High Containment Advantage:</span> Over 91% of customers
              received immediate order tracking milestones and RMA generation without waiting in human queues, saving an estimated 142 agent labor hours this month.
            </div>
          </div>
        </div>

        {/* Live Activity Stream */}
        <div className="bg-white/5 backdrop-blur-2xl p-6 rounded-2xl border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-green-400" /> Recent Bot Actions
            </h3>
          </div>

          <div className="space-y-3.5 divide-y divide-white/5">
            {analytics.recentActivity.map((act) => (
              <div key={act.id} className="pt-3 first:pt-0 space-y-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">{act.customer}</span>
                  <span className="text-[10px] text-white/40">{act.time}</span>
                </div>
                <p className="text-[11px] text-white/70">{act.action}</p>
                <div className="flex items-center gap-1.5 pt-0.5">
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      act.status === 'success'
                        ? 'bg-green-400'
                        : act.status === 'escalated'
                        ? 'bg-amber-400'
                        : 'bg-indigo-400'
                    }`}
                  />
                  <span className="text-[10px] text-white/40 capitalize">{act.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
