import React from 'react';
import {
  MessageSquare,
  Package,
  Radio,
  BarChart3,
  Code2,
  Columns,
  Moon,
  Sun,
  Settings,
  Sparkles,
} from 'lucide-react';

export type AppViewMode = 'whatsapp' | 'orders' | 'broadcast' | 'analytics' | 'webhooks' | 'split';

interface HeaderProps {
  currentView: AppViewMode;
  onSelectView: (view: AppViewMode) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenSettings: () => void;
  activeOrdersCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onSelectView,
  darkMode,
  onToggleDarkMode,
  onOpenSettings,
  activeOrdersCount,
}) => {
  return (
    <header className="bg-white/5 backdrop-blur-2xl border-b border-white/10 text-white shadow-2xl select-none shrink-0 z-30 transition-all">
      <div className="px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-green-500 rounded-2xl flex items-center justify-center shadow-lg shadow-green-500/25 text-white border border-green-400/30 shrink-0">
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base sm:text-lg tracking-tight text-white">ZapFlow</span>
              <span className="text-[10px] uppercase tracking-wider bg-white/10 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-white/15 backdrop-blur-md">
                WhatsApp Bot AI
              </span>
            </div>
            <p className="text-[11px] text-white/50 hidden sm:block">
              24/7 Automated Inquiries & Live Order Tracking
            </p>
          </div>
        </div>

        {/* Navigation Mode Tabs */}
        <div className="flex items-center bg-white/5 backdrop-blur-xl p-1.5 rounded-2xl border border-white/10 text-xs overflow-x-auto no-scrollbar max-w-[50vw] sm:max-w-none shadow-inner">
          <button
            onClick={() => onSelectView('whatsapp')}
            className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
              currentView === 'whatsapp'
                ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/30'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="hidden md:inline">WhatsApp Chat</span>
          </button>

          <button
            onClick={() => onSelectView('orders')}
            className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
              currentView === 'orders'
                ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/30'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Orders Hub</span>
            <span className="px-1.5 py-0.2 bg-white/20 text-white text-[9px] rounded-full font-bold">
              {activeOrdersCount}
            </span>
          </button>

          <button
            onClick={() => onSelectView('split')}
            className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
              currentView === 'split'
                ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/30'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
            title="Side-by-side WhatsApp Simulator & Orders Tracker"
          >
            <Columns className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">Split Screen</span>
          </button>

          <button
            onClick={() => onSelectView('broadcast')}
            className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
              currentView === 'broadcast'
                ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/30'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Broadcaster</span>
          </button>

          <button
            onClick={() => onSelectView('analytics')}
            className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
              currentView === 'analytics'
                ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/30'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Analytics</span>
          </button>

          <button
            onClick={() => onSelectView('webhooks')}
            className={`px-3 py-1.5 rounded-xl font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
              currentView === 'webhooks'
                ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/30'
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">API & QR</span>
          </button>
        </div>

        {/* Right Tools */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleDarkMode}
            className="p-2 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all text-white/80 hover:text-white backdrop-blur-md"
            title="Toggle Light / Dark WhatsApp Theme"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-indigo-300" />}
          </button>

          <button
            onClick={onOpenSettings}
            className="p-2 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all text-white/80 hover:text-white backdrop-blur-md"
            title="Bot Rules & Automation Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
