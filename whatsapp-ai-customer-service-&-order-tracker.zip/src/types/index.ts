export type MessageSender = 'user' | 'bot' | 'agent' | 'system';

export type MessageStatus = 'sent' | 'delivered' | 'read' | 'pending';

export type MessageType =
  | 'text'
  | 'interactive_buttons'
  | 'interactive_list'
  | 'order_card'
  | 'order_receipt'
  | 'product_card'
  | 'product_carousel'
  | 'audio_note'
  | 'image'
  | 'location'
  | 'human_handoff'
  | 'template_broadcast';

export interface InteractiveButton {
  id: string;
  title: string;
  payload: string;
  icon?: string;
  variant?: 'primary' | 'secondary' | 'danger' | 'success';
}

export interface InteractiveListItem {
  id: string;
  title: string;
  description?: string;
  payload: string;
  badge?: string;
}

export interface InteractiveListSection {
  title: string;
  items: InteractiveListItem[];
}

export interface ChatMessage {
  id: string;
  chatId: string;
  sender: MessageSender;
  senderName?: string;
  type: MessageType;
  content: string;
  timestamp: string;
  status: MessageStatus;
  buttons?: InteractiveButton[];
  listSections?: InteractiveListSection[];
  orderId?: string;
  orderData?: Order;
  productData?: Product;
  productsList?: Product[];
  mediaUrl?: string;
  mediaCaption?: string;
  audioDuration?: number; // in seconds
  locationData?: {
    latitude: number;
    longitude: number;
    name: string;
    address: string;
  };
  sentiment?: 'positive' | 'neutral' | 'frustrated' | 'urgent';
  agentEscalated?: boolean;
}

export type OrderStatus =
  | 'placed'
  | 'processing'
  | 'shipped'
  | 'out_for_delivery'
  | 'delivered'
  | 'return_requested'
  | 'refunded'
  | 'cancelled';

export interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  image: string;
  sku: string;
  specs?: string;
}

export interface TrackingCheckpoint {
  id: string;
  status: string;
  description: string;
  location: string;
  timestamp: string;
  completed: boolean;
  current?: boolean;
}

export interface CourierInfo {
  name: string;
  trackingNumber: string;
  trackingUrl: string;
  driverName?: string;
  driverPhone?: string;
  driverVehicle?: string;
  currentCoordinates?: {
    lat: number;
    lng: number;
  };
  etaWindow?: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  items: OrderItem[];
  subtotal: number;
  shippingCost: number;
  discount: number;
  total: number;
  status: OrderStatus;
  createdAt: string;
  estimatedDelivery: string;
  deliveredAt?: string;
  shippingAddress: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  courier: CourierInfo;
  checkpoints: TrackingCheckpoint[];
  paymentMethod: string;
  paymentStatus: 'paid' | 'pending' | 'refunded';
  notes?: string;
  canCancel?: boolean;
  canReturn?: boolean;
  returnReason?: string;
}

export interface CustomerChat {
  id: string;
  phone: string;
  name: string;
  avatar: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  status: 'active' | 'bot_handling' | 'human_agent' | 'resolved';
  linkedOrderId?: string;
  tags: string[];
  totalOrdersCount: number;
  lifetimeValue: number;
  isOnline?: boolean;
  typing?: boolean;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  description: string;
  inStock: boolean;
  stockCount: number;
  features: string[];
}

export interface StoreFAQ {
  id: string;
  question: string;
  answer: string;
  category: 'shipping' | 'returns' | 'payment' | 'orders' | 'warranty' | 'general';
  keywords: string[];
}

export interface DiscountCode {
  code: string;
  description: string;
  discountPercent: number;
  validUntil: string;
  minSpend?: number;
}

export interface WhatsAppTemplate {
  id: string;
  name: string;
  category: 'MARKETING' | 'UTILITY' | 'AUTHENTICATION';
  language: string;
  header?: string;
  body: string;
  footer?: string;
  buttons?: { type: 'QUICK_REPLY' | 'URL' | 'PHONE_NUMBER'; text: string; value?: string }[];
}

export interface BotAutomationSettings {
  botName: string;
  businessName: string;
  businessPhone: string;
  businessAddress: string;
  businessHours: string;
  welcomeMessage: string;
  outOfHoursMessage: string;
  fallbackMessage: string;
  autoHandoffKeywords: string[];
  tone: 'professional' | 'friendly' | 'concise' | 'playful';
  enableTypingSimulation: boolean;
  enableAudioResponses: boolean;
  enableInteractiveButtons: boolean;
  quickReplyShortcuts: { label: string; action: string }[];
}

export interface BotAnalytics {
  totalInquiries: number;
  resolvedByBot: number;
  escalatedToAgents: number;
  avgResponseTimeMs: number;
  csatRating: number;
  totalOrdersTracked: number;
  inquiriesByCategory: {
    category: string;
    count: number;
    percentage: number;
  }[];
  recentActivity: {
    id: string;
    time: string;
    customer: string;
    action: string;
    status: 'success' | 'escalated' | 'pending';
  }[];
}
