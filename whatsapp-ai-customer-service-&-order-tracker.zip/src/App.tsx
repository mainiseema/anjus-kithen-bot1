import React, { useState, useEffect } from 'react';
import {
  CustomerChat,
  ChatMessage,
  Order,
  OrderStatus,
  WhatsAppTemplate,
  BotAutomationSettings,
} from './types';
import {
  INITIAL_CUSTOMER_CHATS,
  INITIAL_ORDERS,
  DEFAULT_BOT_SETTINGS,
} from './data/mockData';
import { sendChatMessage } from './services/api';
import { Header, AppViewMode } from './components/common/Header';
import { WhatsAppSidebar } from './components/whatsapp/WhatsAppSidebar';
import { WhatsAppChat } from './components/whatsapp/WhatsAppChat';
import { OrdersManager } from './components/admin/OrdersManager';
import { BroadcastCenter } from './components/admin/BroadcastCenter';
import { AnalyticsDashboard } from './components/admin/AnalyticsDashboard';
import { WebhookInspector } from './components/admin/WebhookInspector';
import { BotSettingsModal } from './components/admin/BotSettingsModal';
import confetti from 'canvas-confetti';

export default function App() {
  const [currentView, setCurrentView] = useState<AppViewMode>('whatsapp');
  const [darkMode, setDarkMode] = useState(true);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [settings, setSettings] = useState<BotAutomationSettings>(DEFAULT_BOT_SETTINGS);

  // Core Data Stores
  const [chats, setChats] = useState<CustomerChat[]>(INITIAL_CUSTOMER_CHATS);
  const [activeChatId, setActiveChatId] = useState<string>(INITIAL_CUSTOMER_CHATS[0].id);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [isTyping, setIsTyping] = useState(false);

  // Chat message histories map
  const [chatMessages, setChatMessages] = useState<Record<string, ChatMessage[]>>(() => {
    const alexOrder = INITIAL_ORDERS.find((o) => o.id === 'ORD-9821')!;
    const priyaOrder = INITIAL_ORDERS.find((o) => o.id === 'ORD-7742')!;
    const sarahOrder = INITIAL_ORDERS.find((o) => o.id === 'ORD-5501')!;

    return {
      'chat-alex': [
        {
          id: 'msg-seed-1',
          chatId: 'chat-alex',
          sender: 'user',
          type: 'text',
          content: 'Hi, where is my order ORD-9821 right now?',
          timestamp: '08:34 AM',
          status: 'read',
        },
        {
          id: 'msg-seed-2',
          chatId: 'chat-alex',
          sender: 'bot',
          type: 'order_card',
          content:
            '📦 *Live Order Tracking: #ORD-9821*\n\n• *Status:* 🛵 *Out for Delivery Today!*\n• *Estimated Delivery:* *Today by 4:30 PM*\n• *Courier:* FedEx Express Direct (`FDX-9982-1402-99`)\n• *Driver ETA:* *2:30 PM – 4:30 PM (6 stops away)*\n• *Destination:* 742 Evergreen Terrace, Springfield\n• *Items:* Sony WH-1000XM5 Headphones (x1), Protection Case (x1)',
          timestamp: '08:35 AM',
          status: 'read',
          orderId: 'ORD-9821',
          orderData: alexOrder,
          buttons: [
            { id: 'btn-d1', title: '📞 Contact Courier Driver', payload: 'driver_call_ORD-9821', variant: 'primary' },
            { id: 'btn-d2', title: '🚪 Gate / Drop-off Note', payload: 'gate_note_ORD-9821', variant: 'secondary' },
          ],
        },
      ],
      'chat-priya': [
        {
          id: 'msg-seed-3',
          chatId: 'chat-priya',
          sender: 'user',
          type: 'text',
          content: 'Hello! I received order ORD-7742 yesterday but I need to exchange it for a different armrest.',
          timestamp: 'Yesterday',
          status: 'read',
        },
        {
          id: 'msg-seed-4',
          chatId: 'chat-priya',
          sender: 'bot',
          type: 'text',
          content:
            '🔄 *Instant Return & Exchange Generator*\n\n• *Order:* #ORD-7742\n• *Item:* Ergonomic Mesh Office Chair\n• *Policy:* 30-Day Hassle-Free Free Returns\n\n*RMA Return Label #RMA-849201* has been generated! You can download your prepaid return label or select an exchange model below:',
          timestamp: 'Yesterday',
          status: 'read',
          orderId: 'ORD-7742',
          orderData: priyaOrder,
          buttons: [
            { id: 'btn-p1', title: '📄 Download Return Label PDF', payload: 'download_label', variant: 'primary' },
            { id: 'btn-p2', title: '🔄 Choose Exchange Model', payload: 'exchange_request', variant: 'secondary' },
          ],
        },
      ],
      'chat-marcus': [
        {
          id: 'msg-seed-5',
          chatId: 'chat-marcus',
          sender: 'user',
          type: 'text',
          content: 'Do you offer international shipping to Canada and what is the delivery time?',
          timestamp: 'Yesterday',
          status: 'read',
        },
        {
          id: 'msg-seed-6',
          chatId: 'chat-marcus',
          sender: 'bot',
          type: 'text',
          content:
            '🚚 *Shipping Speeds & Delivery Options*\n\n• *Standard Shipping (3-5 business days):* FREE over $50 ($4.99 otherwise)\n• *Express Priority (1-2 business days):* $14.99\n• *International Express (5-8 business days):* Available to Canada & 40+ countries\n\nUse promo code *`WHATSAPP10`* for 10% off your checkout today!',
          timestamp: 'Yesterday',
          status: 'read',
          buttons: [
            { id: 'btn-m1', title: '🛒 Browse Catalog', payload: 'browse_catalog', variant: 'primary' },
            { id: 'btn-m2', title: '🏷️ Active Promo Codes', payload: 'discount_codes', variant: 'success' },
          ],
        },
      ],
      'chat-sarah': [
        {
          id: 'msg-seed-7',
          chatId: 'chat-sarah',
          sender: 'user',
          type: 'text',
          content: 'I noticed my monitor tracking hasn’t updated since Friday. Is it delayed?',
          timestamp: 'Aug 23',
          status: 'read',
        },
        {
          id: 'msg-seed-8',
          chatId: 'chat-sarah',
          sender: 'bot',
          type: 'order_card',
          content:
            '📦 *Live Order Tracking: #ORD-5501*\n\n• *Status:* 🚚 *Shipped & In Transit*\n• *Estimated Delivery:* *Tomorrow, Aug 25 by 7:00 PM*\n• *Courier:* UPS Ground Premier (`1Z9999999999999999`)\n• *Latest Checkpoint:* Departed Philadelphia UPS hub\n• *Destination:* Boston, MA\n\nYour package is moving on schedule and scheduled for local Boston delivery tomorrow!',
          timestamp: 'Aug 23',
          status: 'read',
          orderId: 'ORD-5501',
          orderData: sarahOrder,
          buttons: [
            { id: 'btn-s1', title: '🏠 Change Address', payload: 'change address for ORD-5501', variant: 'secondary' },
            { id: 'btn-s2', title: '👨‍💼 Speak to Agent', payload: 'agent', variant: 'primary' },
          ],
        },
      ],
    };
  });

  // Apply dark mode class to root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const activeChat = chats.find((c) => c.id === activeChatId) || chats[0];
  const currentMessages = chatMessages[activeChatId] || [];

  // Send Message Handler
  const handleSendMessage = async (text: string, type: ChatMessage['type'] = 'text', extraData?: any) => {
    const userMsgId = `msg-user-${Date.now()}`;
    const userMsg: ChatMessage = {
      id: userMsgId,
      chatId: activeChatId,
      sender: 'user',
      type,
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      ...extraData,
    };

    // Update conversation history with user message
    setChatMessages((prev) => ({
      ...prev,
      [activeChatId]: [...(prev[activeChatId] || []), userMsg],
    }));

    // Update sidebar last message
    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChatId
          ? {
              ...c,
              lastMessage: text,
              lastMessageTime: userMsg.timestamp,
              unreadCount: 0,
            }
          : c
      )
    );

    // Simulate WhatsApp Double Check Delivery & Read Status
    setTimeout(() => {
      setChatMessages((prev) => ({
        ...prev,
        [activeChatId]: (prev[activeChatId] || []).map((m) =>
          m.id === userMsgId ? { ...m, status: 'delivered' } : m
        ),
      }));
    }, 250);

    setTimeout(() => {
      setChatMessages((prev) => ({
        ...prev,
        [activeChatId]: (prev[activeChatId] || []).map((m) =>
          m.id === userMsgId ? { ...m, status: 'read' } : m
        ),
      }));
    }, 500);

    // Simulate Bot Typing Indicator
    setIsTyping(true);

    try {
      const { replyMessage, updatedOrder, escalated } = await sendChatMessage({
        message: text,
        chat: activeChat,
        history: currentMessages,
      });

      setTimeout(() => {
        setIsTyping(false);

        // Append Bot Reply
        setChatMessages((prev) => ({
          ...prev,
          [activeChatId]: [...(prev[activeChatId] || []), replyMessage],
        }));

        // Update active chat status if escalated
        if (escalated) {
          setChats((prev) =>
            prev.map((c) =>
              c.id === activeChatId
                ? {
                    ...c,
                    status: 'human_agent',
                    lastMessage: replyMessage.content.slice(0, 60),
                  }
                : c
            )
          );
        } else {
          setChats((prev) =>
            prev.map((c) =>
              c.id === activeChatId
                ? {
                    ...c,
                    lastMessage: replyMessage.content.slice(0, 60),
                  }
                : c
            )
          );
        }

        // Sync order update if any
        if (updatedOrder) {
          setOrders((prev) =>
            prev.map((o) => (o.id.toUpperCase() === updatedOrder.id.toUpperCase() ? updatedOrder : o))
          );
        }
      }, 700);
    } catch (err) {
      setIsTyping(false);
      console.error('Error handling chat reply:', err);
    }
  };

  // Update order status from Orders Hub
  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus, note?: string) => {
    const updatedOrders = orders.map((o) => {
      if (o.id.toUpperCase() === orderId.toUpperCase()) {
        const updated: Order = {
          ...o,
          status,
          notes: note || o.notes,
          deliveredAt: status === 'delivered' ? new Date().toISOString() : o.deliveredAt,
        };
        return updated;
      }
      return o;
    });

    setOrders(updatedOrders);

    // Find linked customer chat and send proactive WhatsApp alert
    const targetChat = chats.find((c) => c.linkedOrderId === orderId);
    if (targetChat) {
      const order = updatedOrders.find((o) => o.id === orderId)!;
      let proactiveText = '';

      if (status === 'out_for_delivery') {
        proactiveText = `🚚 *WhatsApp Delivery Update: Out for Delivery Today!*\n\nHi *${order.customerName}*, your courier *${order.courier.name}* is on route with order *#${order.id}*.\n\n• *Estimated arrival:* *${order.estimatedDelivery}*\n• *Courier Tracking:* \`${order.courier.trackingNumber}\``;
      } else if (status === 'delivered') {
        proactiveText = `🎉 *WhatsApp Delivery Confirmed!*\n\nHi *${order.customerName}*, order *#${order.id}* has just been delivered to *${order.shippingAddress.street}*.\n\nWe hope you love your new items! Reply here if you need any assistance or invoice download.`;
      } else if (status === 'shipped') {
        proactiveText = `📦 *WhatsApp Shipping Update: Order Shipped!*\n\nHi *${order.customerName}*, your package *#${order.id}* has departed our central hub via *${order.courier.name}*. Tracking: \`${order.courier.trackingNumber}\``;
      }

      if (proactiveText) {
        const botMsg: ChatMessage = {
          id: `msg-proactive-${Date.now()}`,
          chatId: targetChat.id,
          sender: 'bot',
          type: 'order_card',
          content: proactiveText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'delivered',
          orderId: order.id,
          orderData: order,
          buttons: [
            { id: 'btn-tr', title: '📍 View Live GPS Checkpoints', payload: `track ${order.id}`, variant: 'primary' },
            { id: 'btn-help', title: '❓ Help with this Order', payload: 'returns_help', variant: 'secondary' },
          ],
        };

        setChatMessages((prev) => ({
          ...prev,
          [targetChat.id]: [...(prev[targetChat.id] || []), botMsg],
        }));

        setChats((prev) =>
          prev.map((c) =>
            c.id === targetChat.id
              ? {
                  ...c,
                  lastMessage: proactiveText.slice(0, 60),
                  unreadCount: c.id === activeChatId ? 0 : c.unreadCount + 1,
                }
              : c
          )
        );
      }
    }
  };

  // Trigger Proactive Notification from Broadcast Center or Orders Hub
  const handleSendProactiveNotification = (
    order: Order,
    type: 'shipped' | 'out_for_delivery' | 'delivered'
  ) => {
    handleUpdateOrderStatus(order.id, type);
  };

  // Broadcast Center template dispatcher
  const handleSendBroadcast = (template: WhatsAppTemplate, targetPhone: string, variables: string[]) => {
    const targetChat =
      chats.find((c) => c.phone.replace(/\D/g, '') === targetPhone.replace(/\D/g, '')) || chats[0];

    let body = template.body;
    variables.forEach((v, idx) => {
      body = body.replace(`{{${idx + 1}}}`, v || '');
    });

    const msgContent = `${template.header ? `*${template.header}*\n\n` : ''}${body}${
      template.footer ? `\n\n_${template.footer}_` : ''
    }`;

    const broadcastMsg: ChatMessage = {
      id: `msg-bcast-${Date.now()}`,
      chatId: targetChat.id,
      sender: 'bot',
      type: 'template_broadcast',
      content: msgContent,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'delivered',
      buttons: template.buttons
        ? template.buttons.map((b, i) => ({
            id: `btn-b-${i}`,
            title: b.text,
            payload: b.text,
            variant: 'primary',
          }))
        : undefined,
    };

    setChatMessages((prev) => ({
      ...prev,
      [targetChat.id]: [...(prev[targetChat.id] || []), broadcastMsg],
    }));

    setChats((prev) =>
      prev.map((c) =>
        c.id === targetChat.id
          ? {
              ...c,
              lastMessage: msgContent.slice(0, 60),
              unreadCount: c.id === activeChatId ? 0 : c.unreadCount + 1,
            }
          : c
      )
    );
  };

  // Add new chat
  const handleAddNewChat = (newChatData: Partial<CustomerChat>) => {
    const newChatId = `chat-${Date.now()}`;
    const newChat: CustomerChat = {
      id: newChatId,
      name: newChatData.name || 'New Customer',
      phone: newChatData.phone || '+1 (555) 000-0000',
      avatar: newChatData.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      lastMessage: newChatData.lastMessage || 'Hello!',
      lastMessageTime: 'Just now',
      unreadCount: 0,
      status: 'bot_handling',
      linkedOrderId: newChatData.linkedOrderId,
      tags: newChatData.tags || ['New Chat'],
      totalOrdersCount: newChatData.totalOrdersCount || 0,
      lifetimeValue: newChatData.lifetimeValue || 0,
      isOnline: true,
    };

    setChats((prev) => [newChat, ...prev]);
    setActiveChatId(newChatId);

    // Seed welcome bot message
    setChatMessages((prev) => ({
      ...prev,
      [newChatId]: [
        {
          id: `msg-w-${Date.now()}`,
          chatId: newChatId,
          sender: 'bot',
          type: 'interactive_buttons',
          content: settings.welcomeMessage,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'delivered',
          buttons: [
            { id: 'btn-nw-1', title: '📦 Track My Order', payload: 'track_order', variant: 'primary' },
            { id: 'btn-nw-2', title: '🛍️ Browse Products', payload: 'browse_catalog', variant: 'secondary' },
            { id: 'btn-nw-3', title: '🔄 Returns & Refunds', payload: 'returns_help', variant: 'secondary' },
            { id: 'btn-nw-4', title: '🏷️ Active Promos', payload: 'discount_codes', variant: 'success' },
          ],
        },
      ],
    }));

    if (currentView !== 'whatsapp' && currentView !== 'split') {
      setCurrentView('whatsapp');
    }
  };

  // Add new order
  const handleAddNewOrder = (order: Order) => {
    setOrders((prev) => [order, ...prev]);
    confetti({ particleCount: 30, spread: 50 });
  };

  // Open Chat directly from Orders Hub
  const handleOpenChatWithOrder = (orderId: string) => {
    const existingChat = chats.find((c) => c.linkedOrderId === orderId);
    if (existingChat) {
      setActiveChatId(existingChat.id);
    }
    setCurrentView('whatsapp');
  };

  const handleClearChat = () => {
    setChatMessages((prev) => ({
      ...prev,
      [activeChatId]: [
        {
          id: `msg-reset-${Date.now()}`,
          chatId: activeChatId,
          sender: 'bot',
          type: 'interactive_buttons',
          content: 'Chat history cleared. How can I help you today?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'delivered',
          buttons: [
            { id: 'btn-c1', title: '📦 Track Order (ORD-9821)', payload: 'track ORD-9821', variant: 'primary' },
            { id: 'btn-c2', title: '🛒 Browse Products', payload: 'browse_catalog', variant: 'secondary' },
            { id: 'btn-c3', title: '🏷️ Discount Codes', payload: 'discount_codes', variant: 'success' },
          ],
        },
      ],
    }));
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0f172a] bg-gradient-to-br from-[#0f172a] via-[#1e1b4b] to-[#312e81] text-white overflow-hidden font-sans antialiased relative">
      {/* Ambient background blur lights */}
      <div className="absolute top-[-10%] left-[-5%] w-[40vw] h-[40vw] rounded-full bg-indigo-600/15 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-5%] w-[45vw] h-[45vw] rounded-full bg-emerald-600/10 blur-[130px] pointer-events-none" />

      {/* Top Application Header */}
      <Header
        currentView={currentView}
        onSelectView={setCurrentView}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenSettings={() => setShowSettingsModal(true)}
        activeOrdersCount={orders.filter((o) => o.status !== 'delivered' && o.status !== 'cancelled').length}
      />

      {/* Main View Area with Frosted Glass Layout Container */}
      <main className="flex-1 flex p-2 sm:p-4 md:p-6 gap-4 sm:gap-6 overflow-hidden relative z-10">
        {/* WhatsApp Simulator View */}
        {currentView === 'whatsapp' && (
          <div className="flex-1 flex h-full overflow-hidden bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] shadow-2xl">
            <WhatsAppSidebar
              chats={chats}
              activeChatId={activeChatId}
              onSelectChat={(id) => {
                setActiveChatId(id);
                setChats((prev) =>
                  prev.map((c) => (c.id === id ? { ...c, unreadCount: 0 } : c))
                );
              }}
              onAddNewChat={handleAddNewChat}
              orders={orders}
            />
            <WhatsAppChat
              chat={activeChat}
              messages={currentMessages}
              orders={orders}
              onSendMessage={handleSendMessage}
              isTyping={isTyping}
              onClearChat={handleClearChat}
            />
          </div>
        )}

        {/* Split Screen View (WhatsApp Simulator + Orders Hub Side-by-side) */}
        {currentView === 'split' && (
          <div className="flex-1 flex h-full overflow-hidden gap-4 sm:gap-6">
            {/* Left: WhatsApp Chat Screen */}
            <div className="w-full lg:w-[480px] xl:w-[540px] flex flex-col h-full bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] overflow-hidden shrink-0 shadow-2xl">
              <div className="bg-white/10 backdrop-blur-md text-white px-4 py-2.5 text-xs font-bold flex items-center justify-between border-b border-white/10">
                <span className="flex items-center gap-1.5 text-emerald-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  WhatsApp Simulator
                </span>
                <span className="text-[11px] text-white/60 font-mono">
                  {activeChat.name}
                </span>
              </div>
              <WhatsAppChat
                chat={activeChat}
                messages={currentMessages}
                orders={orders}
                onSendMessage={handleSendMessage}
                isTyping={isTyping}
                onClearChat={handleClearChat}
              />
            </div>

            {/* Right: Orders Management Hub */}
            <div className="flex-1 h-full overflow-hidden flex flex-col bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] shadow-2xl p-4 sm:p-6">
              <OrdersManager
                orders={orders}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onSendProactiveNotification={handleSendProactiveNotification}
                onAddNewOrder={handleAddNewOrder}
                onOpenChatWithOrder={handleOpenChatWithOrder}
              />
            </div>
          </div>
        )}

        {/* Orders Management Hub */}
        {currentView === 'orders' && (
          <div className="flex-1 h-full overflow-hidden flex flex-col bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] shadow-2xl p-4 sm:p-6">
            <OrdersManager
              orders={orders}
              onUpdateOrderStatus={handleUpdateOrderStatus}
              onSendProactiveNotification={handleSendProactiveNotification}
              onAddNewOrder={handleAddNewOrder}
              onOpenChatWithOrder={handleOpenChatWithOrder}
            />
          </div>
        )}

        {/* WhatsApp Template Broadcaster */}
        {currentView === 'broadcast' && (
          <div className="flex-1 h-full overflow-hidden flex flex-col bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] shadow-2xl p-4 sm:p-6">
            <BroadcastCenter onSendBroadcast={handleSendBroadcast} />
          </div>
        )}

        {/* Analytics & Performance Dashboard */}
        {currentView === 'analytics' && (
          <div className="flex-1 h-full overflow-hidden flex flex-col bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] shadow-2xl p-4 sm:p-6">
            <AnalyticsDashboard />
          </div>
        )}

        {/* Webhook & Graph API Inspector */}
        {currentView === 'webhooks' && (
          <div className="flex-1 h-full overflow-hidden flex flex-col bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2rem] shadow-2xl p-4 sm:p-6">
            <WebhookInspector />
          </div>
        )}
      </main>

      {/* Bot Automation Settings Modal */}
      <BotSettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        settings={settings}
        onSave={setSettings}
      />
    </div>
  );
}
