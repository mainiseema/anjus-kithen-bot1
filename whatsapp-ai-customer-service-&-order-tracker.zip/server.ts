import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_ORDERS, INITIAL_FAQS, DISCOUNT_CODES, INITIAL_PRODUCTS } from './src/data/mockData';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// In-memory store initialized with seed orders
let ordersDb = [...INITIAL_ORDERS];

// Initialize Google Gen AI client with recommended headers
let genAI: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  genAI = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// System prompt for WhatsApp Customer Support Agent
const WHATSAPP_SYSTEM_INSTRUCTION = `
You are "SwiftBot", the official AI WhatsApp customer service assistant for "ZapFlow Electronics & Living".
Your role is to assist customers warmly, concisely, and efficiently via WhatsApp.

Key Guidelines:
1. Tone & Format:
   - Friendly, polite, and helpful.
   - ALWAYS format your response using authentic WhatsApp markdown:
     - Use *bold* for emphasis, headers, dates, status, or key numbers.
     - Use bullet points (• ) for lists.
     - Keep paragraphs short (1-3 sentences) suitable for mobile chat screens.
     - Use relevant emojis naturally (📦, 🚚, ⚡, 🔍, 🏷️, 💬, 🛠️, ✨).
2. Domain Capabilities:
   - Order Tracking: Look up order IDs (like ORD-9821, ORD-7742, ORD-5501, ORD-1234) or phone numbers.
   - Return & Refund Policy: 30-day hassle-free returns on all products.
   - Shipping Rates: Free standard shipping over $50; Express next-day $14.99; International 5-8 business days.
   - Active Promo Codes: 'WHATSAPP10' (10% off), 'FREESHIP' (Free shipping over $50), 'VIP20' (20% off over $100).
   - Human Escalation: If customer expresses strong frustration or specifically asks for a human agent, reassure them politely and confirm an escalation.
3. Keep responses direct without generic robotic fluff.
`;

// Helper to find order by text
function findOrderInText(text: string) {
  const match = text.match(/ORD-\d{4}/i);
  if (match) {
    const orderId = match[0].toUpperCase();
    return ordersDb.find((o) => o.id.toUpperCase() === orderId);
  }
  // Try matching phone digits
  const phoneDigits = text.replace(/\D/g, '');
  if (phoneDigits.length >= 7) {
    return ordersDb.find((o) => o.customerPhone.replace(/\D/g, '').includes(phoneDigits));
  }
  return null;
}

// API Routes
app.get('/api/orders', (req: Request, res: Response) => {
  res.json({ success: true, orders: ordersDb });
});

app.get('/api/orders/:id', (req: Request, res: Response) => {
  const order = ordersDb.find((o) => o.id.toUpperCase() === req.params.id.toUpperCase());
  if (!order) {
    return res.status(404).json({ success: false, message: 'Order not found' });
  }
  res.json({ success: true, order });
});

app.post('/api/orders/:id/update-status', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, note } = req.body;
  const orderIndex = ordersDb.findIndex((o) => o.id.toUpperCase() === id.toUpperCase());
  if (orderIndex === -1) {
    return res.status(404).json({ success: false, message: 'Order not found' });
  }

  ordersDb[orderIndex] = {
    ...ordersDb[orderIndex],
    status,
    notes: note || ordersDb[orderIndex].notes,
  };

  res.json({ success: true, order: ordersDb[orderIndex] });
});

app.post('/api/orders/:id/cancel', (req: Request, res: Response) => {
  const { id } = req.params;
  const { reason } = req.body;
  const orderIndex = ordersDb.findIndex((o) => o.id.toUpperCase() === id.toUpperCase());
  if (orderIndex === -1) {
    return res.status(404).json({ success: false, message: 'Order not found' });
  }

  ordersDb[orderIndex] = {
    ...ordersDb[orderIndex],
    status: 'cancelled',
    notes: `Cancelled by customer. Reason: ${reason || 'Customer request'}`,
  };

  res.json({ success: true, order: ordersDb[orderIndex] });
});

app.post('/api/chat', async (req: Request, res: Response) => {
  const { message, customerId, customerPhone, conversationHistory } = req.body;

  if (!message) {
    return res.status(400).json({ success: false, error: 'Message is required' });
  }

  const matchedOrder = findOrderInText(message) || (customerId ? ordersDb.find((o) => o.customerPhone.includes(customerPhone || '')) : null);

  // Check if we have Gemini AI available
  if (genAI && process.env.GEMINI_API_KEY) {
    try {
      const orderContext = matchedOrder
        ? `\nRelevant Order Found in Database: ID ${matchedOrder.id}, Customer: ${matchedOrder.customerName}, Status: ${matchedOrder.status}, Items: ${matchedOrder.items.map((i) => `${i.name} (x${i.quantity})`).join(', ')}, Total: $${matchedOrder.total}, Estimated Delivery: ${matchedOrder.estimatedDelivery}, Carrier: ${matchedOrder.courier?.name || 'N/A'}, Tracking: ${matchedOrder.courier?.trackingNumber || 'N/A'}`
        : '\nNo specific order identified yet.';

      const promptContext = `
Customer message: "${message}"
${orderContext}
Store Inventory Summary: ${INITIAL_PRODUCTS.map((p) => `${p.name} ($${p.price}, in stock: ${p.inStock})`).join('; ')}
Active Promos: ${DISCOUNT_CODES.map((d) => `${d.code} (${d.description})`).join(', ')}

Please provide a helpful, concise WhatsApp response formatted with WhatsApp markdown (*bold*, lists). If order details were found, reference the specific tracking status.
`;

      const response = await genAI.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: promptContext,
        config: {
          systemInstruction: WHATSAPP_SYSTEM_INSTRUCTION,
          temperature: 0.7,
        },
      });

      const responseText = response.text || "I'm here to help! Could you please provide your Order ID (e.g. `ORD-9821`) or your inquiry?";

      return res.json({
        success: true,
        reply: responseText,
        matchedOrder: matchedOrder || undefined,
        aiPowered: true,
      });
    } catch (err: any) {
      console.warn('Gemini API call fallback to rule engine:', err?.message || err);
    }
  }

  // Fallback Rule-Based Response Engine
  const lower = message.toLowerCase();
  let reply = '';
  let sentiment: 'positive' | 'neutral' | 'frustrated' | 'urgent' = 'neutral';
  let shouldEscalate = false;

  if (lower.includes('agent') || lower.includes('human') || lower.includes('representative') || lower.includes('person')) {
    reply =
      '👨‍💼 *Connecting you with a Senior Support Specialist...*\n\nI have flagged our human support queue. An agent typically responds in *less than 2 minutes* during business hours (8 AM - 9 PM EST).\n\nWhile you wait, I can still pull up order details or invoice downloads!';
    shouldEscalate = true;
    sentiment = 'urgent';
  } else if (matchedOrder) {
    reply = `📦 *Order Status for #${matchedOrder.id}*\n\n• *Status:* *${matchedOrder.status.replace(/_/g, ' ').toUpperCase()}*\n• *Estimated Delivery:* *${matchedOrder.estimatedDelivery}*\n• *Courier:* ${matchedOrder.courier.name} (Tracking: \`${matchedOrder.courier.trackingNumber}\`)\n• *Items:* ${matchedOrder.items.map((i) => `${i.name} (x${i.quantity})`).join(', ')}\n• *Destination:* ${matchedOrder.shippingAddress.city}, ${matchedOrder.shippingAddress.state}\n\n*Would you like live GPS tracking, address changes, or invoice download?*`;
  } else if (lower.includes('track') || lower.includes('where is my') || lower.includes('status')) {
    reply =
      '🔍 *Live Order Tracking*\n\nPlease share your *Order ID* (for example: `ORD-9821`, `ORD-7742`, `ORD-5501`) or your registered *phone number*, and I will instantly retrieve your live package location and delivery ETA!';
  } else if (lower.includes('return') || lower.includes('refund') || lower.includes('exchange')) {
    reply =
      '🔄 *Returns & Exchanges Policy*\n\nWe offer *30-day hassle-free returns* with 100% free return shipping!\n\n• Items must be in original condition.\n• Refunds are credited to original payment within 2-3 business days.\n\nTo initiate a return right now, simply provide your *Order ID* or send a photo of the item!';
  } else if (lower.includes('discount') || lower.includes('coupon') || lower.includes('promo') || lower.includes('code')) {
    reply =
      '🏷️ *Exclusive Active WhatsApp Discount Codes*\n\n• *`WHATSAPP10`* - 10% OFF any order!\n• *`FREESHIP`* - Free Express shipping on orders over $50\n• *`VIP20`* - 20% OFF orders over $100\n\nEnter code at checkout or let me know what item you are looking to purchase!';
  } else if (lower.includes('shipping') || lower.includes('delivery time') || lower.includes('international')) {
    reply =
      '🚚 *Shipping Speeds & Delivery Options*\n\n• *Standard Shipping (3-5 business days):* FREE over $50 ($4.99 otherwise)\n• *Express Priority (1-2 business days):* $14.99\n• *International Express (5-8 business days):* Available to 40+ countries\n\nAll orders include real-time WhatsApp tracking checkpoints.';
  } else if (lower.includes('hello') || lower.includes('hi') || lower.includes('hey') || lower.includes('start')) {
    reply =
      '👋 *Welcome to ZapFlow Support on WhatsApp!*\n\nI am *SwiftBot*, your 24/7 AI shopping & order concierge.\n\n*How can I help you today?*\n• 📦 Track an existing order\n• 🔄 Return or exchange an item\n• 🛒 Check product specs & inventory\n• 🏷️ Active promo codes\n• 💬 Talk to human agent';
  } else {
    reply =
      `Thank you for your message! I'm *SwiftBot* ⚡\n\nI can look up live shipments (e.g. *ORD-9821*), check product stock, process return requests, or connect you to our support desk.\n\n*What would you like assistance with?*`;
  }

  res.json({
    success: true,
    reply,
    matchedOrder: matchedOrder || undefined,
    shouldEscalate,
    sentiment,
    aiPowered: false,
  });
});

// Serve static assets in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (req: Request, res: Response) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`WhatsApp Bot server running on port ${PORT}`);
});
