import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, Plugin } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

function apiServerPlugin(): Plugin {
  let genAI: GoogleGenAI | null = null;
  if (process.env.GEMINI_API_KEY) {
    genAI = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  return {
    name: 'api-server-plugin',
    configureServer(server) {
      server.middlewares.use('/api/chat', async (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.end(JSON.stringify({ error: 'Method not allowed' }));
          return;
        }

        let body = '';
        req.on('data', (chunk) => {
          body += chunk;
        });

        req.on('end', async () => {
          try {
            const data = JSON.parse(body || '{}');
            const userMsg = data.message || '';

            if (genAI && process.env.GEMINI_API_KEY) {
              try {
                const prompt = `
You are "SwiftBot", the official AI WhatsApp customer service assistant for "ZapFlow Electronics & Living".
Format your response with WhatsApp markdown (*bold*, lists).
Customer message: "${userMsg}"
Customer phone: "${data.customerPhone || ''}"
Order query ID if any: ORD-9821, ORD-7742, ORD-5501, ORD-1234.
Store Return Policy: 30-Day Hassle-Free Free Returns.
Shipping: Free over $50, Express $14.99.
Promo: WHATSAPP10 (10% off).
Provide a concise, helpful, friendly WhatsApp customer response.
`;
                const aiRes = await genAI.models.generateContent({
                  model: 'gemini-3.7-flash',
                  contents: prompt,
                  config: {
                    systemInstruction: 'You are SwiftBot, a helpful WhatsApp support assistant. Keep responses formatted with *bold* and lists.',
                  },
                });

                res.setHeader('Content-Type', 'application/json');
                res.end(
                  JSON.stringify({
                    success: true,
                    reply: aiRes.text,
                    aiPowered: true,
                  })
                );
                return;
              } catch (err: any) {
                console.warn('Gemini API call warning in dev middleware:', err?.message);
              }
            }

            // Fallback response
            res.setHeader('Content-Type', 'application/json');
            res.end(
              JSON.stringify({
                success: false,
                message: 'Local rule engine active',
              })
            );
          } catch (e: any) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: e.message }));
          }
        });
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), apiServerPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
